"""铸剑 定稿分片运行。
用法: python run_shard.py --config config_FINAL8.pkl --build all --lo 6000 --hi 10000 --procs 10 --out tony_6000_9999.json
  --build : 入神型 / 大成型 / 伤痕型 / 守价型 / all（四种开局都跑）
  --lo/--hi: 局号区间 [lo, hi)，每局随机种子由局号确定；两台机器区间不能重叠
  分层（身上 0/3/4/5/8 件遗物单剑冲高）也按同一局号区间跑。
"""
import sys, os, json, random, pickle, argparse, time
from multiprocessing import Pool
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from sim import loop_v2 as L
L.DRAFT_DIR = os.path.join(HERE, "sim")
from zj_stats import ext

def make_P(cfg):
    p = dict(cfg["params"]); p["relics_path"] = os.path.join(HERE, "sim", "relic_decisions_v2.py")
    return L.V2Params(**p)

def norm(d):  # JSON 化：元组键 / 整数键
    d = dict(d)
    d["spend_day"] = [[k[0], k[1], v] for k, v in d.get("spend_day", {}).items()]
    d["iron_days"] = [[k, v] for k, v in d.get("iron_days", {}).items()]
    return d

def job(a):
    cfgp, relics, lo, hi = a
    cfg = pickle.load(open(cfgp, "rb")); P = make_P(cfg); data = L.Data(P)
    return [norm(ext(L.RunV2(P, data, relics, random.Random((P.seed*1_000_003+i*7919) ^ 0x2B2B), False).play(), P)) for i in range(lo, hi)]

def pj(a):
    cfgp, relics, lo, hi = a
    cfg = pickle.load(open(cfgp, "rb")); P = make_P(cfg); d = L.Data(P)
    return [list(L.push_one(P, d, relics, random.Random((P.seed*1_000_003+i*7919) ^ 0x5A5A))) for i in range(lo, hi)]

LAYER_N = (0, 3, 4, 5, 8)
def layer_set(w, n): return {0: [], 3: w[:2]+w[4:5], 4: w[:2]+w[4:6], 5: w[:3]+w[4:6], 8: list(w)}[n]

def chunks(lo, hi, k=64):
    s = max(1, (hi-lo)//k); return [(a, min(hi, a+s)) for a in range(lo, hi, s)]

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=os.path.join(HERE, "config_FINAL8.pkl"))
    ap.add_argument("--build", default="all"); ap.add_argument("--lo", type=int, required=True); ap.add_argument("--hi", type=int, required=True)
    ap.add_argument("--procs", type=int, default=10); ap.add_argument("--out", required=True)
    ap.add_argument("--no-layer", action="store_true")
    a = ap.parse_args(); cfgp = os.path.abspath(a.config); cfg = pickle.load(open(cfgp, "rb"))
    builds = list(cfg["wish"]) if a.build == "all" else [a.build]
    t = time.time(); out = {"config": cfg["name"], "lo": a.lo, "hi": a.hi, "python": sys.version.split()[0], "raw": {}, "layer": {}}
    with Pool(a.procs) as pool:
        for b in builds:
            out["raw"][b] = [m for p in pool.map(job, [(cfgp, cfg["wish"][b], x, y) for x, y in chunks(a.lo, a.hi)]) for m in p]
            print(b, "完成", len(out["raw"][b]), "局", round(time.time()-t), "秒", flush=True)
        if not a.no_layer:
            # 分层：按身上遗物总件数 0 / 3 / 4 / 5 / 8（四种开局心愿单各取前若干件）
            for n in LAYER_N:
                for w in (cfg["wish"] if n else list(cfg["wish"])[:1]):
                    rel = layer_set(cfg["wish"][w], n)
                    out["layer"][f"{n}|{w}"] = [x for p in pool.map(pj, [(cfgp, rel, x, y) for x, y in chunks(a.lo, a.hi)]) for x in p]
            print("分层完成", round(time.time()-t), "秒", flush=True)
    json.dump(out, open(a.out, "w", encoding="utf-8"), ensure_ascii=False)
    print("已写出", a.out, round(time.time()-t), "秒")
