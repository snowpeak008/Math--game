铸剑 定稿分片包（需要 Python 3.10+ 和 numpy）
1) 解压到任意目录，例如 C:\zj
2) Windows 命令行（建议先固定哈希种子）：
   cd C:\zj
   set PYTHONHASHSEED=0
   python run_shard.py --config config_FINAL8.pkl --build all --lo 6000 --hi 10000 --procs 10 --out tony_6000_9999.json
   （--build 可写 入神型 / 大成型 / 伤痕型 / 守价型 / all；--lo/--hi 为局号区间 [lo,hi)，两台机器不能重叠）
3) 把 tony_6000_9999.json 传回，与云端分片一起合并：
   python merge.py --config config_FINAL8.pkl --out merged.json cloud_0_5999.json tony_6000_9999.json
4) 对照实验（商人不卖特殊剑，同一批局号）：--config config_FINAL8_nosp.pkl
