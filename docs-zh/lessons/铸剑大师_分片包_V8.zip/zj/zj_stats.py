"""统计函数（与云端 rg2.py 同源）"""
import numpy as np
def ext(r,P):
    sd=r.get("sold_detail") or []; wi=r.get("win_info")
    d=dict(win=r["win"],earned=r["earned"],ref=r["gold_refresh"],mer=r["gold_merchant"],
           iron_g=r["gold_merchant_iron_early"]+r["gold_merchant_iron_late"],rw=r["gold_merchant_rewind"],sp=r.get("gold_merchant_special",0),
           m_iron=r["merchant_iron"],n_sp=r.get("merchant_special",0),sp_day=r.get("special_day"),spend_day=r.get("spend_day",{}),iron_days=r.get("iron_days",{}),first_buy=r.get("first_buy_vill"),set1=r.get("vill_set1"),stuck=r.get("stuck",0),stuck_e=r.get("stuck_early",0),
           day=r.get("day_log",[]),ebv=r.get("earned_by_vill",[]),nvill=r["vill"],
           sales=[(x["vill"],x["L"],x["gold"],x["tier"],x.get("pool",1.0)) for x in sd],opens=[1 if x["L"]>=99 else 0 for x in sd])
    d["pre"]=r["earned"]; d["sales_pre"]=d["sales"]
    if wi:
        d["wi"]=dict(wi); d["wi"]["one"]=wi["last_gold"]>=P.target
        if wi["last_gold"]>0: d["pre"]=r["earned"]-wi["last_gold"]; d["sales_pre"]=d["sales"][:-1]
    return d
def q(a,ps=(10,25,50,75,90)): return [float(np.percentile(a,p)) for p in ps] if len(a) else None
def stats(raw,P):
    E=[r for r in raw if r["earned"]>0]; fr=lambda k: float(np.mean([r[k]/r["earned"] for r in E]))
    W=[r for r in raw if r["win"]]; nw=max(1,len(W))
    full=[r for r in raw if r["set1"] is not None]
    o=dict(n=len(raw),win=float(np.mean([r["win"] for r in raw])),
      refresh=fr("ref"),merchant=fr("mer"),iron=fr("iron_g"),rewind=fr("rw"),special=fr("sp"),
      iron_buys=float(np.mean([r["m_iron"] for r in raw])),
      sp_n=float(np.mean([r["n_sp"] for r in raw])),sp_day=float(np.mean([r["sp_day"] for r in raw if r["sp_day"]])) if any(r["sp_day"] for r in raw) else None,
      sp_share=float(np.mean([r["n_sp"]>0 for r in raw])),
      win_sp=float(np.mean([r["win"] for r in raw if r["n_sp"]>0])) if any(r["n_sp"]>0 for r in raw) else None,
      win_nosp=float(np.mean([r["win"] for r in raw if r["n_sp"]==0])) if any(r["n_sp"]==0 for r in raw) else None,
      sold99=float(np.mean([sum(r["opens"])/len(r["opens"]) for r in raw if r["opens"]])),
      full_share=len(full)/len(raw),full_win=(sum(r["win"] for r in full)/len(full)) if full else None,
      full_day=float(np.mean([r["set1"] for r in full])) if full else None,
      win_pre_full=sum(1 for r in W if r["wi"]["max_set"]<4)/nw,
      win_special=sum(1 for r in W if r["wi"].get("last_special"))/nw,
      win_lastL=np.bincount(np.clip([r["wi"].get("last_L",0)//5 for r in W],0,19),minlength=20).tolist() if W else None,
      win_nab=np.bincount([min(4,r["wi"].get("nab",0)) for r in W],minlength=5).tolist() if W else None,
      win_nab_full=np.bincount([r["wi"].get("nab",0) for r in W],minlength=11).tolist() if W else None,
      win_M=q([r["sales"][-1][4] if len(r["sales"][-1])>4 else 1 for r in W]) if W else None, win_one=sum(1 for r in W if r["wi"]["one"])/nw,
      win_vill_med=float(np.median([r["wi"]["vill"] for r in W])) if W else None,
      win_maxL=np.bincount(np.clip([r["wi"]["max_sold"]//10 for r in W],0,9),minlength=10).tolist() if W else None,
      first_buy_mean=float(np.mean([r["first_buy"] for r in raw if r["first_buy"]])) if any(r["first_buy"] for r in raw) else None,
      first_buy_le3=float(np.mean([bool(r["first_buy"]) and r["first_buy"]<=3 for r in raw])),
      first_buy_never=float(np.mean([not r["first_buy"] for r in raw])),
      stuck_runs=float(np.mean([r["stuck"]>0 for r in raw])),stuck_early_runs=float(np.mean([r["stuck_e"]>0 for r in raw])),
      fail_by8=float(np.mean([(not r["win"]) and r["nvill"]<=8 for r in raw])))
    # 前3天：开剑/碎剑/剩铁/锤数
    for d in range(3):
        rows=[r["day"][d] for r in raw if len(r["day"])>d]
        o[f"d{d+1}"]=dict(open=float(np.mean([x[0] for x in rows])),brk=float(np.mean([x[3] for x in rows])),iron=float(np.mean([x[1] for x in rows])),
                          nR=float(np.mean([x[2] for x in rows])),strikes=float(np.mean([x[4] for x in rows])))
    # 三档平均卖价
    tiers={"前期(无2件)":(0,1),"中期(2-3件)":(2,3),"后期(满4)":(4,99)}
    for nm,(a,b) in tiers.items():
        g=[s[2] for r in raw for s in r["sales"] if a<=s[3]<=b]
        o["sale_"+nm]=dict(mean=float(np.mean(g)) if g else None,median=float(np.median(g)) if g else None,n=len(g))
    # 每天平均卖剑收入（当天有交剑时）& 到场时累计收入分位
    day_sale={}
    for r in raw:
        for v,Lv,gd,t,*__ in r["sales"]: day_sale.setdefault(v,[]).append(gd)
    o["day_sale_mean"]={v:float(np.mean(day_sale[v])) for v in sorted(day_sale) if v<=25}
    o["day_sale_median"]={v:float(np.median(day_sale[v])) for v in sorted(day_sale) if v<=25}
    vis={}
    for r in raw:
        for v in range(3,26,4):  # 到场首日(3,7,11..) 开始时的累计收入 = 前一天结束
            if len(r["ebv"])>=v-1: vis.setdefault(v,[]).append(r["ebv"][v-2])
    o["earned_at_visit"]={v:q(x) for v,x in vis.items()}
    # 逐天：当天卖剑收入中位/均值（存活局）、累计收入中位（当天结束）、周期(两天到场日)收入中位
    dm={}; dmean={}; cm={}; cyc={}
    for d in range(1,26):
        al=[r for r in raw if r["nvill"]>=d]
        if not al: continue
        inc=[sum(g for v,_,g,_,*__ in r["sales"] if v==d) for r in al]
        dm[d]=float(np.median(inc)); dmean[d]=float(np.mean(inc))
        cm[d]=float(np.median([r["ebv"][d-1] for r in al if len(r["ebv"])>=d]))
    for c in range(0,6):
        d1,d2=4*c+3,4*c+4; al=[r for r in raw if r["nvill"]>=d1]
        if al: cyc[d1]=float(np.median([sum(g for v,_,g,_,*__ in r["sales"] if v in (d1,d2)) for r in al]))
    # 按商人周期(4天: 1-4,5-8,...)：铁/刷新/其它 各占该周期卖剑收入（全体局合计比） + 全局
    cyc_sp={}
    for c in range(7):
        days=range(4*c+1,4*c+5); inc=sum(g for r in raw for v,_,g,_,*__ in r["sales"] if v in days)
        sp={t:sum(x for r in raw for (v,tt),x in r["spend_day"].items() if v in days and tt==t) for t in ("iron","ref","other")}
        if inc>0: cyc_sp[f"{4*c+1}-{4*c+4}"]={t:sp[t]/inc for t in sp}|{"sum":sum(sp.values())/inc,"inc_total":inc}
    tot=sum(r["earned"] for r in raw); cyc_sp["全局(总额比)"]={t:sum(x for r in raw for (v,tt),x in r["spend_day"].items() if tt==t)/tot for t in ("iron","ref","other")}
    cyc_sp["全局(总额比)"]["sum"]=sum(cyc_sp["全局(总额比)"].values())
    o["cycle_spend"]=cyc_sp
    # 新口径：分母 = 通关那把之前的累计卖剑收入（未通关=全部）
    P2=[r for r in raw if r["pre"]>0]; fp=lambda g: float(np.mean([g(r)/r["pre"] for r in P2]))
    sp_t=lambda r,t: sum(x for (v,tt),x in r["spend_day"].items() if tt==t)
    o["pre_mean"]={t:fp(lambda r,t=t: sp_t(r,t)) for t in ("iron","ref","other")}; o["pre_mean"]["sum"]=sum(o["pre_mean"].values())
    o["pre_mean"]["special"]=fp(lambda r:r["sp"])
    totp=sum(r["pre"] for r in P2); o["pre_agg"]={t:sum(sp_t(r,t) for r in P2)/totp for t in ("iron","ref","other")}; o["pre_agg"]["sum"]=sum(o["pre_agg"].values())
    o["pre_agg"]["special"]=sum(r["sp"] for r in P2)/totp
    cyp={}
    for c in range(7):
        days=range(4*c+1,4*c+5); inc=sum(g for r in raw for v,_,g,_,*__ in r["sales_pre"] if v in days)
        sp={t:sum(x for r in raw for (v,tt),x in r["spend_day"].items() if v in days and tt==t) for t in ("iron","ref","other")}
        if inc>0: cyp[f"{4*c+1}-{4*c+4}"]={t:sp[t]/inc for t in sp}|{"sum":sum(sp.values())/inc}
    o["cycle_spend_pre"]=cyp
    cmp_={}; cmn={}
    for c in range(6):
        d1,d2=4*c+3,4*c+4; al=[r for r in raw if r["nvill"]>=d1]
        if al:
            x=[sum(g for v,_,g,_,*__ in r["sales_pre"] if v in (d1,d2)) for r in al]; cmp_[d1]=float(np.median(x)); cmn[d1]=float(np.mean(x))
    o["cycle_inc_med_pre"]=cmp_; o["cycle_inc_mean_pre"]=cmn
    # 每周期实买铁块数（每局平均）、特殊剑：通关前买过占比
    o["iron_per_cycle"]={f"{4*c+3}/{4*c+4}":float(np.mean([r["iron_days"].get(4*c+3,0)+r["iron_days"].get(4*c+4,0) for r in raw])) for c in range(6)}
    o["sp_before_win_share"]=float(np.mean([r["n_sp"]>0 for r in raw]))
    o["day_inc_med"]=dm; o["day_inc_mean"]=dmean; o["cum_med"]=cm; o["cycle_inc_med"]=cyc
    return o
