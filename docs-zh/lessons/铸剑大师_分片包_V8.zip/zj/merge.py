"""合并多台机器的分片 json，按局号排序后统一算指标（与单机一次跑完一致）。
用法: python merge.py --config config_FINAL8.pkl --out merged.json cloud_0_5999.json tony_6000_9999.json
"""
import sys, os, json, pickle, argparse
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from run_shard import make_P
from zj_stats import stats

def denorm(d):
    d["spend_day"] = {(v, t): x for v, t, x in d["spend_day"]}
    d["iron_days"] = {int(k): v for k, v in d["iron_days"]}
    d["sales"] = [tuple(x) for x in d["sales"]]; d["sales_pre"] = [tuple(x) for x in d["sales_pre"]]
    return d

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--config", default=os.path.join(HERE, "config_FINAL8.pkl"))
    ap.add_argument("--out", required=True); ap.add_argument("shards", nargs="+"); a = ap.parse_args()
    cfg = pickle.load(open(a.config, "rb")); P = make_P(cfg)
    S = sorted([json.load(open(f, encoding="utf-8")) for f in a.shards], key=lambda s: s["lo"])
    for x, y in zip(S, S[1:]):
        assert x["hi"] <= y["lo"], f"局号区间重叠: [{x['lo']},{x['hi']}) 与 [{y['lo']},{y['hi']})"
        if x["hi"] < y["lo"]: print(f"注意：局号 {x['hi']}~{y['lo']-1} 没跑")
    print("分片:", [(s["lo"], s["hi"], s.get("python")) for s in S])
    res = {}
    for b in S[0]["raw"]:
        raw = [denorm(r) for s in S for r in s["raw"][b]]; res[b] = stats(raw, P)
    if all(s["layer"] for s in S):
        ns = sorted({k.split("|")[0] for k in S[0]["layer"]}, key=int)
        for n in ns:
            lv = np.array([x[0] for k in S[0]["layer"] if k.split("|")[0] == n for s in S for x in s["layer"][k]])
            res[f"layer_n{n}"] = {str(t): round(float((lv >= t).mean())*100, 1) for t in (30, 50, 75, 90, 99)}
    json.dump({"cand": cfg["name"], "N": sum(s["hi"]-s["lo"] for s in S), "res": {"1": res}}, open(a.out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    for b in res:
        r = res[b]; print(b, {k: round(r[k], 4) for k in ("win", "refresh", "iron", "special", "first_buy_mean") if k in r} if "win" in r else r)
