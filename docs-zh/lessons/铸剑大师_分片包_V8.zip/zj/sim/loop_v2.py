"""v2 循环（Tony 10/21 最终规则 + 数值组《遗物平衡_v2》）。独立于 v1 循环，复用源码锻造内核的公式：
- 签池 [崩坏9,损伤2,保持5,出彩12,大圆满2] 与签数类遗物；p_raw = 崩坏签·c/(1−c)·21/9 ÷(其余签) 的占比（ForgeEconomy.Chances）；
  v2 组合规则 p = p_raw/(1+ΣR)（比例类降破坏与羁绊加 R）。入神中无崩坏签；每把剑首次入神开始前不碎。
- 锤击不耗铁；1 铁 = 开一把新剑(+0)。锤间隔 0.64s/速度，速度 = 1+0.15·speed+0.2·loop(非入神)+0.3·bellows(入神)。
- 大圆满 +2 级；价值 V = 320·exp(k·L^p)·里程碑 × M，M = min(M_cap, (1+min(pool_cap,pool)) · set_factor)；set_factor=1+Σ(setN_mult−1) 加算（非乘积），再 cap≤10；羁绊 2件+0.25、4件+1.5 且 R。
- 村民耐心 120 秒（时间=锤数资源）；剑架 1 或 3 格 + 手上 1 把；3 星、0 星失败；持有金币 ≥ 目标即胜。
- 商人（第3–4、7–8…村民在场）：卖铁、后悔发条（撤销一锤含崩坏），价格 = max(5000, 10%·上次交剑价)·3^(已买数，铁与发条共用)，全局上限 8；
  精打细算2件 ×0.7。商店刷新 100G、局内每次 ×1.5。支出全部从持有金币扣除。
所有数值都是参数（V2Params）。"""
from __future__ import annotations
import math, random, json, importlib.util, os
from dataclasses import dataclass, field, replace
from multiprocessing import Pool

DRAFT_DIR = "/workspace/zhujian-relic-balance"
MS_A = {30: 1.5, 50: 2.0, 70: 2.0, 90: 3.0}
MS_C = {20: 1.5, 50: 2.0, 70: 2.0, 90: 3.0}


def load_v2(path=None):
    path = path or os.path.join(DRAFT_DIR, "relic_decisions_v2.py")
    spec = importlib.util.spec_from_file_location("rd2", path)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    return m.D


@dataclass
class V2Params:
    value_k: float = 0.354
    value_p: float = 0.71
    milestones: dict = field(default_factory=lambda: {50: 2.0, 70: 2.0, 90: 3.0})
    m_cap: float = 10.0
    pool_cap: float = 0.5            # 价值印记4件 → 1.0
    set2_mult: float = 1.25
    set4_mult: float = 5.0  # locked v2n2: all-set full-pool M≈7.5
    set4_mult_by_set: dict = None  # v2n: per-set override e.g. {"入神": 5.0}; None=all use set4_mult
    rush_innate_M: float = 1.0     # v2n: extra × on M when 入神>=4 (1.0=off); alternative to raising set4_mult
    set4_R: float = 1.0
    curve_A: float = 0.005           # breakCurve 占位：L≤12:0；12<L<60: A·((L−12)/48)^2；L≥60: A+K·((L−60)/39)^G
    curve_K: float = 0.0243
    curve_G: float = 2.0
    curve_free_to: int = 12
    break_curve: list = None         # 直接给整条曲线时覆盖上面
    curve_c0: float = 0.20           # locked calib: 入神4 P(+99)≈20% with c=c0*(L-12)/87
    break_strike_add: float = 0.0    # v2z5 候选C: 首次入神后每一普通锤 c += add（每把剑计数，换剑重置）；0=off
    set4_R_by_set: dict = None       # v2z5: 非坚城/伤痕满4套的 R 按套覆盖，如 {"入神":3.0,"大成":3.0}；None=全用 set4_R
    set2_R_by_set: dict = None       # v2z5: 2–3 件档 R（任意套，含坚城/伤痕），如 {"入神":0.5}；None=无（坚城仍走 jiancheng_set2_R）
    break_c_max: float = 0.95
    set_break_mult4: dict = None     # v2z5 分档乘法降碎：满4件该套额外 ×m（在现有 R/转伤/大成0.85 之后再乘），如 {"入神":0.2}
    set_break_mult2: dict = None     # v2z5：2–3 件档该套额外 ×m
    dual_break_mult_mode: str = "product"  # v2z5：多套同时生效时 product=连乘 | min=只取最强一档
    win_sell: bool = False
    ab_cap: int = None  # v2z5r4 防碎封顶件数
    ab_decay: float = None  # v2z5r5 防碎多件递减
    ab_seq: tuple = None  # v2z5r6 第 n 件防碎倍率表
    relic_fx: dict = None  # v2z5r7 核心遗物效果数值覆盖
    demand_override: dict = None  # v2z5r7 {天: 等级需求}           # v2z5r3 AI: 任一把剑卖价+持有金币≥通关线就立即交（不再强冲 +99）
    no_sets: bool = False            # v2z5r3 Tony 16:12：去掉一切套装效果（套装计数恒 0），防碎件统一 ×ab_mult/件，原转伤/叠抗机制关闭
    ab_mult: float = 0.47
    ab_relics: tuple = None
    ab_mult_by: dict = None          # v2z5r3: 防碎件逐件倍率 {id: m}（未列出的用 ab_mult）          # None = AB_RELICS
    early_iron_bonus: tuple = None   # v2z5 铁补给：(前 D 个村民, 每人 +k 铁)；None=off
    merchant_visit_stock: int = None  # v2z5 Tony: 商人每次到场最多 N 块铁，下次到场补满且 n 从 0 重算；None=off(旧: 全局 n)
    merchant_visit_mode: str = "pair"  # pair=第3+4天同一次到场 | day=每天单独一次
    merchant_iron_m_mode: str = None   # v2z5: 单次到场内铁涨价模式（如 "geo1.5"）；None=沿用 merchant_m_mode
    merchant_iron_ladder: list = None  # v2z5 Tony: 铁价阶梯 P1<P2<…；第 v 次到场(0起)第 k 块(0起) 价格 = ladder[v+k]（超出末档按末档×ladder_tail_g^超出）
    merchant_ladder_tail_g: float = 3.0
    merchant_iron_formula: tuple = None  # v2z5 Tony 定: (B0,Bgrow,g0,gstep,d0) → P(d,k)=B0·Bgrow^(d−d0)·(g0+gstep·(d−d0))^k，d=当天村民序号，k=本次到场已买块数；优先于 ladder
    dual_focus: bool = False  # v2z5 AI: 双套目标在第一套满4前只买领先套的件
    assemble_done_on_set4: bool = False  # v2z5 AI: 任一目标套满4件即结束“凑套期”开始冲剑
    merchant_iron_ai: str = None       # v2z5: None=旧库存目标AI(铁<3才买) | greedy=买得起就买(预算帽仍生效)
    merchant_special_fixed: tuple = None  # v2z5: 特殊剑固定价 (首把价, 重复倍率)，如 (5e7, 2)；None=旧公式
    merchant_iron_value_k: float = 1.0
    merchant_iron_B_table: dict = None   # v2z5r2: {天: 第1块起价} 覆盖 formula 的 B(d)（倍率仍按 formula）
    merchant_ev_tiers: tuple = (1500.0, 35000.0, 0.20)  # v2z5r2 EV 查表：(无2件新剑期望卖价, 2–3件档期望卖价, 满4件开剑P(+99))；满4件 EV=P99×V(99,M)
    merchant_special_table: dict = None  # v2z5r2: {天: 当日第1把特殊剑价}；第 n 把(本局已买 n) = 表价×special_mult^n
    merchant_special_mult: float = 2.0
    special_break_mult: float = 1.0   # v2z6 FINAL6: 特殊剑每锤碎剑概率 ×k
    special_break_cap: float = 0.6    # v2z6 FINAL6: 特殊剑碎剑概率封顶
    refresh_gold_frac: float = None   # v2z6 FINAL6 AI: 付费刷新只在 价格 ≤ frac × 持有金币 时进行（None=旧AI：买得起就刷）
    merchant_special_ai: str = None      # v2z5r2: "ev" = EV(×2剑) > 价 且 持有金币 ≥ 价 就买（去掉 buy_frac/旧 ev_gate）  # v2z5 价值买铁系数（0.5～1）
    merchant_floor_early: float = None # v2z5: 第1–8村民期间铁/发条底价（None=merchant_floor）
    low_break_refund: tuple = None   # v2z5 对照：(Lmax, 每村民上限 n)：剑在 L<Lmax 碎退 1 铁；None=off        # v2z5: c 上限（仅候选C累加时生效）
    villagers: int = 25
    patience: float = 120.0
    rack: int = 1                    # 剑架格数（手上另有 1 把）
    stars: int = 3
    target: float = 1e9
    iron_min: int = 1  # Tony lock v2e: default iron purse 1–3 per villager
    iron_max: int = 3
    new_sword_iron: int = 1
    forge_iron_reserve: int = 2
    req_value_frac: float = 0.5      # 16–25 号村民 “或价值”：该比例改为价值需求 = 320·G(L)（不含 M）
    merchant: bool = True
    merchant_every: int = 4          # 每 4 个村民一天，在场为每天最后 2 个
    merchant_presence: int = 2
    starter_pick_policy: str = "best"  # v2z2b LOCK (was random) · v2z2-xitong: "random" (legacy uniform 1-of-3) | "best" (deterministic player priority, see RunV2._starter_best)
    fz_gate_emergency: bool = True  # v2z2 LOCK (from 放置 fz5): emergency iron/merchant calls only when merchant present (villagers 3,4 of every 4); False = old anytime
    merchant_floor: float = 5000.0
    merchant_frac: float = 0.05  # Tony/经济 lock v2e: 5% anchor
    merchant_frac_alt: float = 0.10  # legacy alt
    merchant_late_mult: float = 4.0  # legacy v2f; unused by v2g m(n)
    merchant_late_frac: float = None  # v2g segmented: if set, vill>=9 use this frac instead of merchant_frac
    merchant_m_mode: str = "v2g"  # v2g | v2g_contrast | v2f
    merchant_a_low: float = 0.05  # v2h: always on last_sale
    merchant_a_high: float = 0.12  # locked A1b: on run_max after any sold L>=90
    merchant_a_high_unlock_level: int = 90  # switch a_high once any sold level >= this
    merchant_iron_cap: int = 3  # v2k hard cap iron buys/run; 0=disabled
    merchant_rewind_cap: int = 2  # v2j: max rewind purchases/run (shared m(n) with iron)
    merchant_rewind_min_level: int = 50  # v2j AI: only buy rewind if max sword L >= this
    merchant_rewind_require_bad: bool = True  # v2j AI: last strike was break/damage
    dual_R_softcap: float = None  # locked: OFF — dual only 关转伤; was 0.7 over-nerf to ~18%
    dual_convert_gate: bool = True  # v2k: when ≥2 full forge sets, disable cornerstone+spine convert-to-damage
    set_mult_mode: str = "additive"  # v2k: additive | product; additive: set_factor=1+Σ(mult-1)
    merchant_iron_early_max: int = 2  # v2k: before ≥+90 unlock, buy at most this many irons (2 hits spend band; 3 under-spends)
    merchant_iron_late_only_empty: bool = False  # locked A1b: late may refill stock 2–3
    merchant_iron_budget_frac: float = None  # v2l: stop iron buys when cum iron spend > frac*earned; None=off
    merchant_separate_n: bool = False  # v2l: iron and rewind use separate purchase counters for m(n)
    merchant_rewind_m_mode: str = None  # v2l: if set, rewind uses this m_mode (else same as merchant_m_mode)
    jiancheng_set2_R: float = 0.0
    jiancheng_set4_R: float = 0.68  # v2z3 定版 owner (jianmo CALIB 0.66 → 0.68; 0.70 tested worse, 大成+坚城 s2 CI-low 0.98 → P2 for 大成+坚城 CI; was 0.75) · v2y LOCK (with 坚城 pieces +1 iron) · calib: S稳定4 P(+99)≈20% (~5 swords); dual soft-cap separate
    shanghen_set4_R: float = 0.66  # v2z3 jianmo CALIB (was 0.67) · v2z2b LOCK (owner, starter best) · was 0.70 v2x LOCK: 伤痕 forge-first R0.70 (was 0.75 v2u VF calib)
    shanghen_set4_convert: int = 1  # 伤痕4: break→damage converts per sword
    jiancheng_per_sword_convert: bool = True  # locked P0a 逐剑  # v2p: refresh corner/spine uses per sword (like scar_conv)
    merchant_early_floor: float = None  # v2p A1: floor before first sale L>=until; None=off
    merchant_early_floor_until_level: int = 50  # v2p: unlock normal floor after first sold L>=this
    merchant_buy_frac_early: float = None  # v2p A2: buy_frac before first ≥+50 sale; None=off
    shop_value_first_dacheng: bool = False  # v2p: 大成≥2 uses value-first fillers (bs/idol enter pool)
    shop_value_first_forge: bool = True  # locked P0b: forge value-fill ON
    shop_value_first_rush: bool = True  # v2x: 入神≥2 rush value-first (old rule); False = forge-first contrast
    shop_fill_policy: dict = field(default_factory=lambda: {"入神": "value", "大成": "value", "伤痕": "forge", "坚城": "forge"})  # v2x LOCK player policy; None=legacy AI triggers · per-set PLAYER buy policy {set: "value"|"forge"} keyed on the build order's ≥4 target sets; any "value" → legacy value-first triggers, all "forge" → never value-first; None=legacy
    jiancheng_value_fill_strength: float = 0.5  # locked f05 interim (50%/shop dice — player rule TBD deterministic)
    jiancheng_convert_efficacy: float = 1.0  # v2y: restored 1.0 (v2x provisional 0.8 rejected) · v2q (a): P(corner/spine convert succeeds); 1.0=full
    jiancheng_convert_every_n: int = 1  # v2x: per-sword convert only on every n-th sword after 坚城4 (2 = alternate-sword ≈0.5/sword); push_one (open P) unaffected
    jiancheng_run_convert_quota: tuple = None  # v2q (b): (corner,spine) run pool when 坚城4; disables per-sword refresh
    shop_value_first_forge_min: int = 2  # v2t P0b: piece-count gate for forge value-fill (was hardcoded ≥2 half-set); 入神 rush stays ≥2
    shop_value_fill_cap: int = None  # v2t: max value fillers (token/coal/blackstone/idol) in loadout; None=off
    dacheng_full4_break_scale: float = 0.85  # locked 满4 防碎
    dacheng_full4_miss_scale: float = 1.0  # v2t: × hold tickets→success when 大成≥4 (e.g. 0.75/0.80)
    dacheng_full4_R_extra: float = 0.0  # v2t: extra R when 大成≥4 (pool/set4_mult untouched)
    shanghen_full4_break_scale: float = 1.0  # v2u: 伤痕满4 防碎 (lighter than 大成 0.85; e.g. 0.90/0.92)
    jiancheng_value_fill_every_other: bool = False  # v2u peek: deterministic every-other shop value-fill for 坚城 (replace f05 dice)
    jiancheng_value_fill_mode: str = "f0"  # v2x DEFAULT f0 = 坚城 NEVER value-fills (optimal player buying; value-fill was sim-AI behaviour). c23f WITHDRAWN (v2w only). "f05"/None = legacy strength/every_other dice path | v2v P1a deterministic: "e2g" every-other villager + first-full4 guaranteed | "e2f" every-other, first-full4 forge-first | "c23" 2-of-3 villagers | "c23f" forge→value→value cycle from first full4 | "pool_half" fill always, value pool ×scale
    jiancheng_value_pool_scale: float = 0.5  # v2v P1a pool_half: pool contribution × this when 坚城≥4 (only in mode pool_half)
    dual_second_set_iron_discount: int = -2  # v2z2c LOCK +2 (owner) · v2z LOCK was +1 (v2x was +2): second-set relic +N iron/piece (sf9 unchanged) · v2v P1b contrast: −N iron per second-set relic once first set full (min 1); 0=off; v2w: negative = surcharge (−1 → +1 iron)
    assemble_done_when_full: bool = True  # v2w DEFAULT True (sim-AI fix, not a rule change): leave assembling (push to +99) once relic slots are full even if order incomplete
    dual_set_factor_override: float = None  # v2w dual nerf: when ≥2 sets at ≥4 pieces, set_factor := this (baseline additive = 9); None=off
    dual_M_cap: float = None  # v2w dual nerf: when ≥2 sets at ≥4 pieces, M cap := min(m_cap, this); None=off
    dual_skip_offbuild_starter: bool = False  # v2v P1b AI contrast: 8-piece build declines off-build starter (keeps slot)
    merchant_iron_late_stock: int = None  # v2u econ contrast: late stock target (2–3) when a_high unlocked; None=off
    late_demand_scale: float = 1.0  # scale Lreq for villagers 16-25
    late_demand_floor: int = 30
    late_demand_top: int = 50
    early_demand_lo: int = 1
    early_demand_hi: int = 5
    mid_demand_lo: int = 8
    mid_demand_hi: int = 16
    special_counts_to_M: bool = True  # group: special x2 COUNTS toward M<=10
    special_innate_mult: float = 2.0
    merchant_special_enabled: bool = True  # v2z3 jianmo CALIB (was False) · v2n: merchant sells special×2 swords (bank strategy)
    merchant_special_cap: int = 4           # max special buys / run
    merchant_special_price_mult: float = 1.0  # v2z3 jianmo CALIB (was 2.0; first price = floor 1.1e8) · special price = iron_price × this (separate n)
    merchant_special_after_set: bool = True  # only buy specials once primary set assembled
    merchant_special_m_mode: str = "geo2"  # v2z3 jianmo CALIB (was None) · special-sword price growth on repeat buys: None = same m-mode as iron (legacy); any merchant_m mode, or "geo<g>" = g**n (e.g. "geo2")
    merchant_special_floor: float = 1.1e8  # v2z3 jianmo CALIB (was None) · special-sword price anchor: price = price_mult * m_special(n) * max(special_floor, merchant base); None = merchant base only (legacy)
    merchant_special_ev_gate: bool = True  # v2z3 jianmo CALIB (was False) · player-optimal special buy: only if price <= ev_k * ev_p * [value(99, min(cap, 2M)) - value(99, M)], M = current build's M for a +99 sword
    merchant_special_ev_p: float = 0.4  # v2z3 jianmo CALIB (was 0.20) · assumed P(+99) of a fresh sword (≈ open-sword P)
    merchant_special_ev_k: float = 2.5  # v2z3 jianmo CALIB (was 1.0) · risk/greed factor on expected gain
    bank_special_push: bool = True  # v2z3 jianmo CALIB (was False) · AI: prefer push/sell specials to +99
    bank_keep_level: int = 80  # v2z7 AI: 三星时不交的最低囤剑等级（放置：抬高可促使卖中档凑钱）
    bank_release_gold: float = None  # v2z8 AI: 持有金币≥此值时不再囤剑，允许交中档（None=关闭）
    inherit_first_trance_protect: bool = True  # new sword from inherit: protect only until first trance
    inherit_level_cap: int = 0  # 0=off; sensitivity e.g. 20
    starter_pick: bool = True  # default: 1-of-3 free pick then shop-assemble
    starter_1iron_only: bool = True
    delete_dragon_scale: bool = True
    value_scale: float = 0.615  # v2j B1 provisional: V(99,M10)≈2.45e8 (was 0.50≈2e8); pending Tony
    soften_early: bool = False  # soften +1..+20 growth
    remove_ms20: bool = False  # drop +20 milestone if present
    dacheng_set2_great: int = 1  # nerf was 2
    dacheng_set4_great: int = 2  # nerf was 4
    dacheng_oracledie: int = 2  # nerf was 4
    dacheng_pin: int = 1  # nerf was 2
    dacheng_butter: int = 3  # nerf was 5
    bank_99_until: int = 0  # 0=disabled (no AI bank self-restraint)
    bank_push_cap: int = 99
    cornerstone_uses: int = 1   # v2 draft 3; nerf for B3<=25%
    insurance_uses: int = 1
    spine_uses: int = 1
    rivet_break_tickets: int = 1  # was 2
    seal_R: float = 0.0  # was 0.10; folded into set

    fz_impl: tuple = ("ossuary", "dice", "apron", "thirdeye", "wax", "tooth", "silverpermit", "eternalseed", "funeralledger")  # v2z3 放置: 按 relic_decisions_v2 文案补实现的件（每件可单独去掉）
    fz_pool_remove: tuple = ("kingcup", "rage", "sieve", "ghostledger", "lifecontract")  # v2z3 放置: 不出现（超标或无法实现）；效果代码保留，加进 fz_impl 可复测
    fz_kingcup_cap: int = 6  # 测试用（kingcup 不出现）
    fz_rage_cap: int = 4  # 测试用（rage 不出现）
    fz_sieve_every: int = 3  # 测试用（sieve 不出现）
    fz_funeral_iron: int = 1  # v2z3 放置: funeralledger 削为返 1 铁（原文案 2）
    fz_dice_great: int = 3  # dice 每次给的大圆满票数（削一档=2）
    fz_wax_cap: float = 0.15  # wax 价值池上限（削一档=0.10）
    fz_fill_first: tuple = ()  # 放置测试用: 套装凑齐后优先买的补位件
    merchant_cap: int = 10**9  # no buy cap (locked)
    merchant_buy_frac: float = 0.35  # 策略：单件价格 ≤ 持有金币×此值才买
    refresh_first: float = 100.0  # legacy alias; heat mode uses refresh_base
    refresh_mode: str = "heat"  # heat (v2z4 Tony) | flat | last_sale | max5000
    refresh_last_frac: float = 0.01
    refresh_free: int = 1  # v2z4: whole-run free refreshes (was 10)
    refresh_growth: float = 1.6  # v2z4 定稿
    refresh_base: float = 300.0  # v2z4 heat: paid price = ceil(base * growth^heat)
    refresh_decay: float = 0.25  # v2z4 定稿
    refresh_rise: float = 0.0  # deprecated; use refresh_villager_boost in price base
    refresh_villager_boost: float = 0.02  # v2z4 定稿: price = base*(growth+boost*vill_index)^heat
    refresh_last_frac_heat: float = 0.0  # if >0, base_r = max(refresh_base, frac*last_sale)
    refresh_max_per_villager: int = 8
    refresh_gold_frac: float = 0.05
    shop_slots: int = 3
    shop_want_force: int = 0
    shop_want_force_late: int = 2  # forced slots after shop_weight_until
    shop_set_weight: float = 3.0  # weight multiplier for same-set relics in offers
    shop_weight_until: int = 8  # before this villager use shop_set_weight_early
    shop_set_weight_early: float = 1.2
    relic_slots: int = 8
    seed: int = 1
    relics_path: str = None
    relic_override: dict = field(default_factory=dict)   # {id: 铁价}  (absolute per-relic price; no per-set option before v2y)
    set_relic_iron_extra: dict = field(default_factory=lambda: {"坚城": 1})  # v2y LOCK 坚城 pieces +1 iron · {set: +n iron per piece of that set}; {}=off
    relic_iron_extra: dict = field(default_factory=lambda: {"bellows": 1, "obsidian": 1, "scales": 1})  # v2z3 jianmo CALIB (was {}) · v2y: {relic id: +n iron} relative per-piece extra (same dual_mode handling); {}=off
    set_membership_remove: dict = field(default_factory=lambda: {"大成": ["glass"]})  # v2z LOCK: glass counts only for 入神 (de-overlap 入神/大成); {}=data as-is
    dual_surcharge_waive_if_full: list = field(default_factory=lambda: ["坚城"])  # v2z1 LOCK: once a listed set has 4 pieces, other-set pieces skip the second-set surcharge; []=off
    # v2z3 (jianmo): villager-related relics — one param per relic; default = verdict (A=implemented ON); None/0/1.0 = old v2z2 (no effect)
    supply_iron: tuple = (12, 1)  # 实现(削) supply: every N-th villager (i%N==0) brings +k iron on arrival [opt 3rd = run cap on iron]; trimmed from (4,1) (forced +4.6–6.5pp); None=off
    hook_iron: tuple = (1, 1)  # 实现(削) hook: each PAID relic-shop refresh → next villager +k iron, max n/run; trimmed from (1,3) (forced +4.3–5.1pp); None=off
    collector_iron: tuple = (12, 1)  # 实现(削) collector: every N-th satisfied villager → +k iron immediately [opt 3rd = run cap]; trimmed from (3,1) (forced +6.0–8.8pp); None=off
    letter_demand_mult: float = 0.9  # 实现 letter: level demand floor(L×m), value demand ×m; 1.0=off
    royalchange_relief: tuple = (10, 3)  # 实现 royalchange: delivered L − level demand ≥ gap → next villager level demand −k (min 0; value-demand villager: wasted); None=off
    voucher_refresh: tuple = (3, 2)  # 实现 voucher: after every N hosted villagers +1 free refresh token (stock ≤ cap), used instead of a paid refresh; None=off
    badge_start: int = 3  # 实现 badge: after a satisfied villager, the next new sword starts at ≥ +k (one sword); 0=off
    testament_inherit: tuple = (30, 0.25, 2)  # 实现 testament: satisfied delivery with L ≥ lmin → next new sword starts at ≥ floor(L×frac), n uses/run; None=off
    relic_not_appear: list = field(default_factory=lambda: ["hearth"])  # v2z3 jianmo 不出现 (hearth: forced +4.9–7.9pp, effect not implemented): removed from shop + starter pool (set membership kept); []=mainline v2z3a pool
    set_relic_iron_extra_dual_mode: str = "max"  # v2z LOCK max (was stack)  # v2y: with dual second-set surcharge: "stack" (extra+surcharge) | "max" (per piece max) | "off" (no set extra in dual-target builds)


# ---------------- 遗物数据 ----------------
class Data:
    def __init__(self, P: V2Params):
        D = load_v2(P.relics_path)
        self.D = D
        self.no_sets = bool(getattr(P, "no_sets", False))
        self.price = {k: int(v["p"]) for k, v in D.items() if v.get("p") is not None}
        self.price.update(P.relic_override)
        self.sets = {}
        for k, v in D.items():
            for s in v.get("s", []):
                if not s.startswith("("):
                    self.sets.setdefault(s, set()).add(k)
        # v2z: rule — remove relics from a set's membership (e.g. glass counts only for 入神)
        for s, ids in (getattr(P, "set_membership_remove", None) or {}).items():
            if s in self.sets:
                self.sets[s] -= set(ids)
        self.pool = [k for k, v in D.items() if v.get("p") is not None and v.get("d") != "删除"]
        _rm = set(getattr(P, "fz_pool_remove", ()) or ())
        if _rm: self.pool = [k for k in self.pool if k not in _rm]
        _na = set(getattr(P, "relic_not_appear", None) or ())  # v2z3 jianmo: villager relics 不出现 (removed from shop + starter pool; set membership kept)
        if _na: self.pool = [k for k in self.pool if k not in _na]
        n = max(P.curve_free_to + 1, 1)
        if P.break_curve:
            c = list(P.break_curve) + [P.break_curve[-1]] * 100
        else:
            c0 = P.curve_c0
            c = [0.0]*12 + [c0*(L-12)/87 for L in range(12,100)]
        self.curve = c[:100]
        self.G = []
        f = 1.0
        ms = dict(P.milestones)
        if P.remove_ms20:
            ms.pop(20, None)
        for L in range(100):
            if L in ms:
                f *= ms[L]
            g = math.exp(P.value_k * L ** P.value_p)
            if P.soften_early and L <= 20:
                # blend toward flatter early: use L^0.35 instead of value_p for L<=20
                g = math.exp(P.value_k * L ** 0.35)
            self.G.append(g * f * P.value_scale)

    def value(self, L, M=1.0):
        return 320.0 * self.G[min(99, L)] * M


AB_RELICS = ("seal", "rivet", "brace", "repair", "star", "thread", "cornerstone", "insurance", "spine", "phoenix")  # v2z5r3 防碎件


def set_counts(R, data):
    c = {}
    if getattr(data, "no_sets", False):
        return c
    mirror = "mirror" in R
    for s, mem in data.sets.items():
        n = len(R & mem)
        if mirror and 1 <= n < 2:
            n = 2   # 万能件只能凑 2 件档
        c[s] = n
    return c


class Build:
    """持有遗物 → 锻造参数（v2 草案效果）。"""
    def __init__(self, R, data: Data, P: V2Params):
        self.R = R = set(R)
        S = self.S = set_counts(R, data)
        t = [9, 2, 5, 12, 2]
        if "sicklehammer" in R: t = [5, 5, 5, 5, 5]
        t[3] += 4 * ("nail" in R) + 6 * ("royalnail" in R) + 2 * ("file" in R) + ("mallet" in R)
        t[2] += -2 * ("file" in R) + 2 * ("hold" in R) + 3 * ("patience" in R) - 2 * ("thorn" in R)
        t[1] += -("mallet" in R) + 2 * ("thorn" in R) + 3 * ("deeppearl" in R)
        t[4] += P.dacheng_pin * ("pin" in R) + ("spark" in R) + P.dacheng_oracledie * ("oracledie" in R) + P.dacheng_butter * ("butterfingers" in R)
        t[4] += P.dacheng_set4_great if S.get("大成", 0) >= 4 else (P.dacheng_set2_great if S.get("大成", 0) >= 2 else 0)
        t[0] = max(1, t[0] - (0 if P.no_sets else P.rivet_break_tickets) * ("rivet" in R) + 3 * ("butterfingers" in R))
        _fi = set(getattr(P, 'fz_impl', ()) or ())
        self.fz = _fi & R
        if 'eternalseed' in self.fz: t[2] += 4
        self.t = [max(0, x) for x in t]
        full_non_jc = sum(1 for k, v in S.items() if v >= 4 and k not in ("坚城", "伤痕"))
        jc = S.get("坚城", 0)
        scar = S.get("伤痕", 0)
        self.R0 = P.seal_R * ("seal" in R)
        # set4 R parts (坚城/伤痕/其他 full sets); soft-cap when ≥2 full forge sets
        r_parts = []
        n_full = full_non_jc + (1 if jc >= 4 else 0) + (1 if scar >= 4 else 0)
        if jc >= 4: r_parts.append(P.jiancheng_set4_R)
        elif jc >= 2: self.R0 += P.jiancheng_set2_R  # set2 not in softcap sum
        if scar >= 4: r_parts.append(P.shanghen_set4_R)
        elif scar >= 2: pass  # set2 scar_next only; no extra R
        _r4 = getattr(P, "set4_R_by_set", None) or {}
        for _sn, _v in S.items():
            if _v >= 4 and _sn not in ("坚城", "伤痕"):
                r_parts.append(float(_r4.get(_sn, P.set4_R)))
        _r2 = getattr(P, "set2_R_by_set", None) or {}
        for _sn, _v in S.items():
            if 2 <= _v < 4 and _sn in _r2:
                self.R0 += float(_r2[_sn])
        r_extra = sum(r_parts)
        soft = getattr(P, "dual_R_softcap", None)
        if soft is not None and n_full >= 2:
            r_extra = min(r_extra, soft)
        self.R0 += r_extra
        # v2t: 大成满4 防碎 — extra R (does not change set4_mult / pool)
        if S.get("大成", 0) >= 4:
            self.R0 += float(getattr(P, "dacheng_full4_R_extra", 0.0) or 0.0)
        self.R_extra_raw = sum(r_parts)
        self.n_ab = len(R & set(getattr(P, "ab_relics", None) or AB_RELICS))
        _m4 = getattr(P, "set_break_mult4", None) or {}; _m2 = getattr(P, "set_break_mult2", None) or {}
        _ms = [float(_m4[k]) for k, v in S.items() if v >= 4 and k in _m4] + \
              [float(_m2[k]) for k, v in S.items() if 2 <= v < 4 and k in _m2]
        if not _ms: self.break_mult = 1.0
        elif getattr(P, "dual_break_mult_mode", "product") == "min": self.break_mult = min(_ms)
        else:
            self.break_mult = 1.0
            for _x in _ms: self.break_mult *= _x
        if P.no_sets:
            self.R0 = 0.0
            _by = getattr(P, "ab_mult_by", None) or {}
            self.break_mult = 1.0
            _ms = sorted(float(_by.get(_r, P.ab_mult)) for _r in R & set(getattr(P, "ab_relics", None) or AB_RELICS))
            _cap = getattr(P, "ab_cap", None)
            _dec = getattr(P, "ab_decay", None)
            _seq = getattr(P, "ab_seq", None)
            for _i, _m in enumerate(_ms[:int(_cap)] if _cap else _ms):   # v2z5r4: 防碎效果封顶 N 件（取最强 N 件）
                if _seq: self.break_mult *= float(_seq[min(_i, len(_seq) - 1)]); continue   # v2z5r6: 第 n 件倍率按表
                self.break_mult *= (_m ** (float(_dec) ** _i)) if _dec else _m   # v2z5r5: 第 n 件效果递减 ab^(decay^(n-1))
        self.n_full_sets = n_full
        dur = 4 + float((getattr(P, "relic_fx", None) or {}).get("everwick_s", 2)) * ("everwick" in R) + 1 * ("redglass" in R)
        spdF = 1 + 0.15 * ("speed" in R) + 0.3 * ("bellows" in R)
        spdN = 1 + 0.15 * ("speed" in R) + 0.2 * ("loop" in R)
        self.F = int(dur * spdF / 0.64) + 1 + (1 if S.get("入神", 0) >= 2 else 0)
        self.tN = 0.64 / spdN
        self.tF = dur / self.F
        mode = getattr(P, "set_mult_mode", "additive") or "additive"
        by = getattr(P, "set4_mult_by_set", None) or {}
        def _set4_mult(sname):
            return float(by.get(sname, P.set4_mult))
        if mode == "product":
            m = 1.0
            for sname, v in S.items():
                m *= (_set4_mult(sname) if v >= 4 else (P.set2_mult if v >= 2 else 1.0))
            self.set_mult = m
        else:
            # additive into factor: set_factor = 1 + Σ(setN_mult − 1); single set4 → 2.5 (same as product)
            add = 0.0
            for sname, v in S.items():
                if v >= 4:
                    add += (_set4_mult(sname) - 1.0)
                elif v >= 2:
                    add += (P.set2_mult - 1.0)
            self.set_mult = 1.0 + add
        # v2w: generic dual-full-set knobs (only when ≥2 sets at ≥4 pieces)
        self.n_set4 = sum(1 for v in S.values() if v >= 4)
        _ov = getattr(P, "dual_set_factor_override", None)
        if _ov is not None and self.n_set4 >= 2:
            self.set_mult = float(_ov)
        _dc = getattr(P, "dual_M_cap", None)
        self.m_cap = min(P.m_cap, float(_dc)) if (_dc is not None and self.n_set4 >= 2) else P.m_cap
        self.set_mult_mode = mode
        self.pool_cap = (1.0 if S.get("价值", 0) >= 4 else P.pool_cap) + (float((getattr(P, "relic_fx", None) or {}).get("blackstone_cap", 0.0)) if "blackstone" in R else 0.0)  # v2z5r7
        _fx = getattr(P, "relic_fx", None) or {}
        self.static_pool = float(_fx.get("token_pool", 0.15)) * ("token" in R) + float(_fx.get("coal_pool", 0.25)) * ("coal" in R) + 0.10 * ("thorn" in R)  # v2z5r7
        self.inherit = min(0.5 if S.get("薪火", 0) >= 4 else 0.35,
                           0.20 * ("holy" in R) + 0.25 * ("dawnsheath" in R) + (0.10 if S.get("薪火", 0) >= 2 else 0))
        self.fever_great_extra = 1 if S.get("入神", 0) >= 4 else 0
        self.fever_end = ("headless" in R) + (2 if S.get("入神", 0) >= 4 else 0)
        self.merchant_mult = 0.7 if S.get("精打细算", 0) >= 2 else 1.0
        self.iron_every3 = S.get("精打细算", 0) >= 4


class Sword:
    __slots__ = ("L", "charge", "fever", "fev_started", "spine_l", "shield", "brace", "repair", "pool", "star", "thread",
                 "hold_streak", "succ_streak", "succ_n", "strikes", "prev", "pearl", "chime", "gear", "scar_next", "milest",
                 "special", "royal_bank", "scar_conv", "rage_b", "king_t", "dice_r", "tooth_t", "rstreak", "pf_n")

    def __init__(self, L=0, charge=0, special=False, scar_conv=0):
        self.L = L; self.charge = charge; self.fever = 0; self.fev_started = False; self.spine_l = 0; self.shield = False
        self.brace = 0.0; self.repair = 0.0; self.pool = {}; self.star = False; self.thread = False
        self.hold_streak = 0; self.succ_streak = 0; self.succ_n = 0; self.strikes = 0; self.prev = None; self.pearl = 0
        self.chime = 0; self.gear = 0; self.scar_next = False; self.milest = 0; self.special = special
        self.royal_bank = 0; self.scar_conv = scar_conv
        self.rage_b = 0; self.king_t = 0; self.dice_r = False; self.tooth_t = 0; self.rstreak = 0
        self.pf_n = 0  # v2z5: post-first-trance normal strikes on this sword

    def copy(self):
        s = Sword.__new__(Sword)
        for k in Sword.__slots__:
            setattr(s, k, getattr(self, k))
        s.pool = dict(self.pool)
        return s


def M_of(s, B: Build, P):
    pool = B.static_pool + sum(s.pool.values())
    if "blackstone" in B.R and s.L >= 40: pool += float((getattr(P, "relic_fx", None) or {}).get("blackstone_add", 0.30))
    if "idol" in B.R: pool += min(0.45, float((getattr(P, "relic_fx", None) or {}).get("idol_step", 0.05)) * sum(1 for m in range(10, 100, 10) if s.L >= m))
    if getattr(P, "jiancheng_value_fill_mode", None) == "pool_half" and B.S.get("坚城", 0) >= 4:
        pool *= float(getattr(P, "jiancheng_value_pool_scale", 0.5))
    m = (1 + min(B.pool_cap, pool)) * B.set_mult
    # v2n: optional 入神4 innate M bonus (multiplicative, inside cap)
    rush_m = getattr(P, "rush_innate_M", 1.0) or 1.0
    if rush_m != 1.0 and B.S.get("入神", 0) >= 4:
        m *= rush_m
    if getattr(s, "special", False):
        if P.special_counts_to_M:
            m *= P.special_innate_mult
            return min(B.m_cap, m)
        return min(B.m_cap, m) * P.special_innate_mult  # separate, can exceed visual but report both
    return min(B.m_cap, m)


def _padd(s, k, inc, cap):
    s.pool[k] = min(cap, s.pool.get(k, 0.0) + inc)


class RunV2:
    def __init__(self, P: V2Params, data: Data, build_order, rng, start_full=False):
        self.P, self.data, self.rng = P, data, rng
        self.order = list(build_order)
        self.R = set(self.order) if start_full else set()
        self.B = Build(self.R, data, P)
        self.iron = 0; self.gold = 0.0; self.stars = P.stars
        self.swords = []
        self.st = dict(corner=P.cornerstone_uses, insurance=P.insurance_uses, spine=P.spine_uses, phoenix=1, inh_uses=3, refund=3, gt=0, inh=0, mourn=0, twin=3, inh_was=False, pending_special=0, oss=[0,0,0,0,0], oss_n=0, sieve_n=0, funeral=2, tooth_p=0)
        self.m = dict(spent_relic_iron=0, gold_merchant=0.0, gold_merchant_early=0.0, gold_merchant_late=0.0,
                      gold_merchant_iron_early=0.0, gold_merchant_iron_late=0.0,
                      gold_merchant_rewind=0.0, gold_refresh=0.0, earned=0.0, sold=[], sold_detail=[],
                      n99=0, n70=0, n90=0, eaten_ge70=0, gold_ge90=0.0, gold_mid=0.0, sold_M=[],
                      breaks=0,
                      strikes=0, merchant_iron=0, merchant_iron_early=0, merchant_iron_late=0,
                      rewinds=0, refreshes=0, merchant_rewind=0, merchant_special=0,
                      gold_merchant_special=0.0, n99_special=0, last_sale=0.0, max_sale=0.0, vill=0, win=False, fail=False)
        self.mbought = 0; self.refresh_n = 0; self.refresh_heat = 0.0; self.rewind = 0
        self.silver_skip = 0; self.silver_vis = -1
        self.last_bad_strike = False  # v2j: break or damage on last strike
        self._apply_jiancheng_quota()

    # ---- 锻造 ----
    def tickets(self, s, fever):
        t = list(self.B.t); R = self.B.R; P = self.P
        t[3] += min(6, s.gear) if "gear" in R else 0
        if fever: t[4] += int((getattr(self.P, "relic_fx", None) or {}).get("perfectcore_g", 4)) * ("perfectcore" in R)
        if "obsidian" in R and s.L >= 8:
            n = min(2, t[3]); t[3] -= n; t[4] += n
        if s.scar_next: t[3] += 3
        t[4] += min(4, self.st["mourn"])
        fz = self.B.fz
        if fz:
            for k in range(5): t[k] += self.st['oss'][k] if 'ossuary' in fz else 0
            if 'dice' in fz and s.dice_r: t[4] += P.fz_dice_great
            if 'kingcup' in fz: t[4] += min(P.fz_kingcup_cap, s.king_t)
            if 'thirdeye' in fz and s.prev == 'h': t[3] += 4
            if 'tooth' in fz: t[3] += s.tooth_t
        # v2t: 大成满4 miss scale — hold→success (降低 stall / 抬通关)
        if self.B.S.get("大成", 0) >= 4:
            ms = float(getattr(P, "dacheng_full4_miss_scale", 1.0) or 1.0)
            if ms < 1.0 - 1e-12:
                hold = t[2]
                new_hold = hold * ms
                freed = hold - new_hold
                t[2] = new_hold
                t[3] += freed
        return t

    def strike(self, s):
        P, B, R, rng = self.P, self.B, self.B.R, self.rng
        infever = s.fever > 0
        if not infever and s.charge >= 10:
            s.fever = B.F; s.charge = 0; infever = True; s.fev_started = True
        t = self.tickets(s, infever)
        d, h, sc, g = t[1], t[2], t[3], t[4] + (self.st["gt"] if s.strikes == 0 else 0)
        others = d + h + sc + g
        out = None; conv = False
        if not infever and s.fev_started:
            c = self.data.curve[s.L]
            _add = P.break_strike_add
            if _add:
                s.pf_n += 1
                c = min(P.break_c_max, c + _add * s.pf_n)
            if c > 0:
                bw = t[0] * (c / (1 - c)) * 21 / 9
                Rsum = 0.0 if P.no_sets else B.R0 + s.brace + s.repair + (0.67 if s.star else 0) + (0.25 if s.thread else 0) + \
                    (0.3 if (s.prev == "h" and self.B.S.get("静守", 0) >= 2) else 0)
                p = bw / (bw + others) / (1 + Rsum)
                # v2t: 大成满4 防碎 — scale break chance
                if B.S.get("大成", 0) >= 4:
                    p *= float(getattr(P, "dacheng_full4_break_scale", 1.0) or 1.0)
                # v2u: 伤痕满4 防碎 — lighter than 大成
                if B.S.get("伤痕", 0) >= 4:
                    p *= float(getattr(P, "shanghen_full4_break_scale", 1.0) or 1.0)
                p *= B.break_mult
                if getattr(s, "special", False) and float(getattr(P, "special_break_mult", 1.0) or 1.0) != 1.0:
                    p = min(float(getattr(P, "special_break_cap", 0.6)), p * float(P.special_break_mult))
                _hit = rng.random() < p
                if _hit and P.no_sets:
                    self.last_bad_strike = True
                    return B.tN, True
                if _hit:
                    # v2k dual softcap: ≥2 full forge sets → disable cornerstone & spine convert-to-damage
                    # (insurance / scar_conv / phoenix unchanged; single-set 坚城 intact)
                    gate = getattr(P, "dual_convert_gate", True) and getattr(B, "n_full_sets", 0) >= 2
                    if (not gate) and "cornerstone" in R and self.st["corner"] > 0:
                        self.st["corner"] -= 1
                        eff = float(getattr(P, "jiancheng_convert_efficacy", 1.0) or 1.0)
                        if rng.random() < eff:
                            out = "d"
                        else:
                            # efficacy miss: convert attempt spent, sword still breaks
                            self.last_bad_strike = True
                            return B.tN, True
                    elif "insurance" in R and self.st["insurance"] > 0:
                        self.st["insurance"] -= 1; out = "d"
                    elif getattr(s, "scar_conv", 0) > 0:
                        s.scar_conv -= 1; out = "d"
                    elif (not gate) and s.shield:
                        s.shield = False; out = "d"; conv = True
                    elif "phoenix" in R and self.st["phoenix"] > 0:
                        self.st["phoenix"] -= 1; s.L = max(0, s.L - 5); out = "h"
                    else:
                        self.last_bad_strike = True
                        return B.tN, True
        s.star = False; s.thread = False; s.scar_next = False
        if out is None:
            r = rng.random() * others
            out = "d" if r < d else "h" if r < d + h else "s" if r < d + h + sc else "g"
        L = s.L
        if out == "d":
            self.last_bad_strike = True
            loss = 1
            if "deeppearl" in R and s.pearl < 2: s.pearl += 1; loss = 0
            if "crown" in R and rng.random() < self._fx("crown_p", 0.5): loss = 0
            L = max(0, L - loss)
            if "repair" in R: s.repair = min(0.6, s.repair + 0.15)
            if "oath" in R and rng.random() < self._fx("oath_p", 0.4): L += 1
            if "royalseal" in R: s.royal_bank = min(int(self._fx("royal_cap", 4)), s.royal_bank + 1)
            if "ironcomb" in R: _padd(s, "ironcomb", 0.02, 0.2)
            if 'apron' in B.fz: _padd(s, 'apron', 0.01, 0.15)
            if self.B.S.get("伤痕", 0) >= 2: s.scar_next = True
            if not infever and "watch" in R: s.charge += 1
            gate = getattr(P, "dual_convert_gate", True) and getattr(B, "n_full_sets", 0) >= 2
            if (not gate) and "spine" in R and not conv and self.st["spine"] > 0 and not s.shield:
                eff = float(getattr(P, "jiancheng_convert_efficacy", 1.0) or 1.0)
                if rng.random() < eff:
                    s.spine_l += 1
                    if s.spine_l >= 2: s.spine_l = 0; s.shield = True; self.st["spine"] -= 1
            s.succ_streak = 0; s.hold_streak = 0
        elif out == "h":
            self.last_bad_strike = False
            s.hold_streak += 1; s.succ_streak = 0
            if "hold" in R and s.hold_streak % 2 == 0: L += 1
            if "still" in R and rng.random() < 0.4: L += 1
            if "chime" in R: s.chime = min(2, s.chime + 1)
            if "mold" in R: _padd(s, "mold", 0.01, 0.15)
            if "cup" in R: _padd(s, "cup", 0.01, 0.2)
            if 'rage' in B.fz: s.rage_b = min(P.fz_rage_cap, s.rage_b + 1)
            if 'kingcup' in B.fz: s.king_t += 1
            if 'eternalseed' in B.fz: _padd(s, 'eternalseed', 0.01, 0.2)
            if "thread" in R: s.thread = True
            if not infever and "hourglass" in R and rng.random() < 0.5: s.charge += 1
        else:
            self.last_bad_strike = False
            add = 1 if out == "s" else 2
            s.succ_streak += 1; s.hold_streak = 0; s.succ_n += 1
            if out == "g":
                self.st["gt"] = 0
                if infever and "glass" in R and (self._fx("glass_p", 1.0) >= 1 or rng.random() < self._fx("glass_p", 1.0)): add += 1
                if infever: add += B.fever_great_extra
                if not infever and "fork" in R and (self._fx("fork_p", 1.0) >= 1 or rng.random() < self._fx("fork_p", 1.0)): add += 1
                if not infever and "star" in R: s.star = True
                if "bell" in R: _padd(s, "bell", 0.03, 0.3)
                if 'rage' in B.fz and s.rage_b: add += s.rage_b; s.rage_b = 0
                if "royalseal" in R and s.royal_bank:
                    add += s.royal_bank; s.royal_bank = 0
            else:
                if "gear" in R: s.gear += 1
                if "goldgear" in R: _padd(s, "goldgear", 0.01, 0.3)
                if "endlessaxle" in R and s.succ_n % 2 == 0: add += 1
                if "chime" in R and s.chime: add += s.chime; s.chime = 0
            if "glove" in R and s.succ_streak % 2 == 0: add += 1
            if "echo" in R and rng.random() < 0.25: add += 1
            if "firstseal" in R and s.strikes == 0: add += 2
            if "scales" in R and s.prev == "d": add += int(self._fx("scales_add", 2))
            if "coin" in R: _padd(s, "coin", 0.01, 0.15)
            if "knot" in R and s.succ_streak % 2 == 0: _padd(s, "knot", 0.02, 0.2)
            if not infever and "brace" in R: s.brace = min(0.30, s.brace + 0.05)
            L += add
        if "incense" in R and s.prev is not None and s.prev != out: _padd(s, "incense", 0.01, 0.2)
        if infever and "collar" in R: _padd(s, "collar", 0.02, 0.3)
        if B.fz:
            s.dice_r = ('dice' in B.fz) and out in ('d', 'h')
            s.rstreak = (s.rstreak + 1) if s.prev == out else 1
            if 'wax' in B.fz and s.rstreak % 2 == 0: _padd(s, 'wax', 0.01, self.P.fz_wax_cap)
        s.prev = out; s.strikes += 1
        if infever:
            s.fever -= 1
            if s.fever == 0: L += B.fever_end
            dt = B.tF
        else:
            s.charge += 1 + (2 if ("locket" in R and s.strikes == 1) else 0)
            dt = B.tN
        s.L = min(L, 99)
        if "twinseal" in R and s.L <= 30 and self.st["twin"] > 0 and rng.random() < 0.02 and len(self.swords) < 1 + self.P.rack:
            self.st["twin"] -= 1; self.swords.append(s.copy())
        return dt, False

    def on_break(self, s):
        R = self.B.R
        self.m["breaks"] += 1
        _lb = getattr(self.P, "low_break_refund", None)
        if _lb and s.L < _lb[0] and self.st.get("lbr_n", 0) < _lb[1]:
            self.st["lbr_n"] = self.st.get("lbr_n", 0) + 1; self.iron += 1; self.m["lbr_iron"] = self.m.get("lbr_iron", 0) + 1
        if "grudge" in R: self.st["gt"] = min(8, s.L // 5)
        if self.B.inherit > 0 and self.st["inh_uses"] > 0 and s.L > 0:
            self.st["inh"] = int(s.L * self.B.inherit); self.st["inh_uses"] -= 1; self.st["inh_was"] = True
        if "shard" in R and self.st["refund"] > 0 and s.L >= 30:
            self.st["refund"] -= 1; self.iron += 1
        fz = self.B.fz
        if fz:
            if 'ossuary' in fz and s.L >= 40 and s.prev in ('d','h','s','g') and self.st['oss_n'] < 3:
                self.st['oss'][{'d':1,'h':2,'s':3,'g':4}[s.prev]] += 1; self.st['oss_n'] += 1
            if 'sieve' in fz:
                self.st['sieve_n'] += 1
                if self.st['sieve_n'] % self.P.fz_sieve_every == 0: self.iron += 1; self.m['fz_iron'] = self.m.get('fz_iron', 0) + 1
            if 'funeralledger' in fz and s.L >= 60 and self.st['funeral'] > 0:
                self.st['funeral'] -= 1; self.iron += self.P.fz_funeral_iron; self.m['fz_iron'] = self.m.get('fz_iron', 0) + self.P.fz_funeral_iron
            if 'tooth' in fz and s.L >= 4: self.st['tooth_p'] = 4

    def new_sword(self, special=False):
        if self.iron < self.P.new_sword_iron:
            return None
        self.iron -= self.P.new_sword_iron
        self.m["iron_swords"] = self.m.get("iron_swords", 0) + self.P.new_sword_iron
        L = 0; ch = 0
        if self.st["inh"] > 0:
            L = self.st["inh"]; self.st["inh"] = 0
            if self.P.inherit_level_cap > 0:
                L = min(L, self.P.inherit_level_cap)
            if self.B.S.get("薪火", 0) >= 4: ch = 10
            # inherited sword: protection only if never entered trance (new instance → fev_started False)
            # unless inherit_first_trance_protect is False → mark as already tranced
        # v2z3: testament / badge raise the start level (max with break-inherit, no stacking)
        if self.st.get("testa", 0) > 0 and "testament" in self.B.R:
            L = max(L, self.st["testa"]); self.st["testa"] = 0; self.st["testa_uses"] = self.st.get("testa_uses", 0) + 1
            self.m["vr_testament"] = self.m.get("vr_testament", 0) + 1
        if self.st.get("badge") and "badge" in self.B.R:
            self.st["badge"] = False
            if L < self.P.badge_start: L = self.P.badge_start; self.m["vr_badge"] = self.m.get("vr_badge", 0) + 1
        scar_n = self.P.shanghen_set4_convert if self.B.S.get("伤痕", 0) >= 4 else 0
        if (not special) and self.st.get("pending_special", 0) > 0:
            special = True
            self.st["pending_special"] -= 1
        if 'lifecontract' in self.B.fz: L = max(L, 6)
        s = Sword(L, ch, special=special, scar_conv=scar_n)
        if 'tooth' in self.B.fz and self.st['tooth_p']: s.tooth_t = self.st['tooth_p']; self.st['tooth_p'] = 0
        if self.st.get("inh_was") and not self.P.inherit_first_trance_protect:
            s.fev_started = True
        self.st["inh_was"] = False
        self._refresh_jiancheng_convert()
        self.swords.append(s)
        return s

    def _apply_jiancheng_quota(self):
        """v2q (b): once 坚城≥4, set corner/spine to run quota (no per-sword refresh)."""
        P = self.P
        q = getattr(P, "jiancheng_run_convert_quota", None)
        if not q:
            return
        if self.st.get("jc_quota_applied"):
            return
        if self.B.S.get("坚城", 0) < 4:
            return
        self.st["corner"] = int(q[0])
        self.st["spine"] = int(q[1])
        self.st["jc_quota_applied"] = True

    def _refresh_jiancheng_convert(self):
        """v2p: like 伤痕 scar_conv — each sword gets corner/spine uses when 坚城4 + flag.
        v2q (b): if run quota set, apply once and do not refresh per sword."""
        P = self.P
        if getattr(P, "jiancheng_run_convert_quota", None):
            self._apply_jiancheng_quota()
            return
        if not getattr(P, "jiancheng_per_sword_convert", False):
            return
        if self.B.S.get("坚城", 0) < 4:
            return
        self.st["corner"] = P.cornerstone_uses
        self.st["spine"] = P.spine_uses
        # v2x: alternate-sword convert — only every n-th sword (after 坚城4) gets corner/spine uses
        n_every = int(getattr(P, "jiancheng_convert_every_n", 1) or 1)
        if n_every > 1:
            k = self.st.get("jc_conv_sw", 0)
            self.st["jc_conv_sw"] = k + 1
            if k % n_every != 0:
                self.st["corner"] = 0
                self.st["spine"] = 0

    def _early_sale_unlocked(self, level=None):
        """True once any sold sword has L >= level (default merchant_early_floor_until_level)."""
        if level is None:
            level = getattr(self.P, "merchant_early_floor_until_level", 50)
        sold = self.m.get("sold") or []
        return any(L >= level for L in sold)

    def _effective_buy_frac(self, critical=False):
        P = self.P
        frac = P.merchant_buy_frac
        early = getattr(P, "merchant_buy_frac_early", None)
        if early is not None and not self._early_sale_unlocked():
            frac = early
        if critical:
            frac = max(frac, 0.8)
        return frac

    def _effective_merchant_floor(self):
        P = self.P
        floor = P.merchant_floor
        early = getattr(P, "merchant_early_floor", None)
        if early is not None and not self._early_sale_unlocked():
            floor = early
        fe = getattr(P, "merchant_floor_early", None)
        if fe is not None and self.m.get("vill", 0) <= 8:
            floor = fe
        return floor

    # ---- 商店/商人 ----
    def shop(self, i):
        P, data = self.P, self.data
        if len(self.R) >= P.relic_slots:
            return
        want = [r for r in self.order if r not in self.R]
        if not want:
            # complementary fillers: value-first so token/coal/bs/idol enter pool.
            # v2p: 入神 always (≥2 rush — UNCHANGED); 大成 if shop_value_first_dacheng (≥2).
            # v2q/v2t P0b: forge sets ≥ shop_value_first_forge_min (was 2 half-set; v2t contrast 3/4 full).
            # v2s: 坚城 uses jiancheng_value_fill_strength (0=exclude, 0.5=dice/shop interim, 1.0=full).
            # v2t: shop_value_fill_cap limits value relics (token/coal/bs/idol); deterministic alt to f05 dice.
            # 价值 builds stay forge-first. Default non-rush was forge-first (starved pool → M≈5).
            forge_min = int(getattr(P, "shop_value_first_forge_min", 2) or 2)
            has_rush = getattr(P, "shop_value_first_rush", True) and self.B.S.get("入神", 0) >= 2  # v2x: gate (False = 入神 forge-first contrast) · 入神 rush: old value-first rule, never gated by forge_min
            has_dacheng = getattr(P, "shop_value_first_dacheng", False) and self.B.S.get("大成", 0) >= 2
            p0b = getattr(P, "shop_value_first_forge", False)
            # P0b for non-坚城 forge sets (入神/大成/伤痕) at forge_min
            has_forge_other = p0b and any(self.B.S.get(s, 0) >= forge_min for s in ("入神", "大成", "伤痕"))
            # 坚城-specific strength (also gated by forge_min)
            jc_str = getattr(P, "jiancheng_value_fill_strength", 1.0)
            if jc_str is None:
                jc_str = 1.0
            jc_str = float(jc_str)
            has_jc = p0b and self.B.S.get("坚城", 0) >= forge_min
            jc_mode = getattr(P, "jiancheng_value_fill_mode", None)
            if jc_mode == "f05":
                jc_mode = None  # v2w: explicit legacy f05 dice path
            if has_jc and jc_mode:
                first4 = self.B.S.get("坚城", 0) >= 4 and not self.st.get("jc_first4_seen")
                if self.B.S.get("坚城", 0) >= 4:
                    self.st["jc_first4_seen"] = True
                if jc_mode == "f0":
                    has_jc_fill = False  # v2x: 坚城-specific value-fill never fires (== legacy strength=0)
                elif jc_mode == "pool_half":
                    has_jc_fill = True
                elif jc_mode == "e2g":
                    has_jc_fill = True if first4 else (i % 2 == 0)
                elif jc_mode == "e2f":
                    if first4:
                        self.st["jc_e2_phase"] = i % 2  # this villager forge-first; value on the next one
                    has_jc_fill = (i % 2) != self.st.get("jc_e2_phase", 1)
                elif jc_mode == "c23":
                    has_jc_fill = (i % 3) != 0
                elif jc_mode == "c23f":
                    # first shop after full 4 = forge-first; then cycle forge→value→value
                    if first4:
                        self.st["jc_c3_phase"] = i % 3
                    has_jc_fill = (i % 3) != self.st.get("jc_c3_phase", 0)
                else:
                    raise ValueError(jc_mode)
                self.m["jc_fill_calls"] = self.m.get("jc_fill_calls", 0) + 1
                self.m["jc_fill_on"] = self.m.get("jc_fill_on", 0) + int(has_jc_fill)
            elif has_jc and (jc_str > 0 or getattr(P, "jiancheng_value_fill_every_other", False)):
                if getattr(P, "jiancheng_value_fill_every_other", False):
                    # v2u peek: deterministic every-other shop() call (replace f05 dice)
                    n = self.st.get("jc_fill_n", 0)
                    self.st["jc_fill_n"] = n + 1
                    has_jc_fill = (n % 2 == 0)
                elif jc_str >= 1.0:
                    has_jc_fill = True
                else:
                    # e.g. 0.5 → 50% chance this shop call uses value-first for 坚城 (interim; not player-facing)
                    has_jc_fill = self.rng.random() < jc_str
            else:
                has_jc_fill = False
            has_val = self.B.S.get("价值", 0) >= 2
            forge = ["glass","perfectcore","everwick","bellows","seal","nail","echo","headless","speed","loop","rivet","cornerstone"]
            # v2q: token/coal/blackstone/idol priority (then weak static)
            value_core = ["token", "coal", "blackstone", "idol"]
            value = value_core + ["coin", "knot", "bell", "incense"]
            value_first = (has_rush or has_dacheng or has_forge_other or has_jc_fill) and not has_val
            _pol = getattr(P, "shop_fill_policy", None)
            if _pol and self._order_sets():
                if not any(_pol.get(k) == "value" for k in self._order_sets()):
                    value_first = False  # v2x: player forge-first for this build
            pref = (value + forge) if value_first else (forge + value)
            self.m["fill_calls"] = self.m.get("fill_calls", 0) + 1
            self.m["value_first_calls"] = self.m.get("value_first_calls", 0) + int(value_first)
            _ff = list(getattr(P, 'fz_fill_first', ()) or ())
            if _ff: pref = _ff + [r for r in pref if r not in _ff]
            fill = [r for r in pref if r not in self.R and r in data.pool]
            # v2t value-slot cap: limit core value relics in loadout
            vcap = getattr(P, "shop_value_fill_cap", None)
            if vcap is not None:
                vcap = int(vcap)
                have = sum(1 for r in self.R if r in value_core)
                room = max(0, vcap - have)
                capped = []
                used = 0
                for r in fill:
                    if r in value_core:
                        if used >= room:
                            continue
                        used += 1
                    capped.append(r)
                fill = capped
            want = fill[: max(0, P.relic_slots - len(self.R))]
            if not want:
                return
        tries = 0
        # reserve 1 iron for a new sword until we have ≥4 relics, else reserve 0 to finish set
        reserve = 1 if len(self.R) < 6 else P.forge_iron_reserve
        while True:
            pool = [r for r in data.pool if r not in self.R]
            # hunt set: optional forced slots + weighted same-set offers
            offers = []
            wpool = [r for r in want if r in pool]
            force_n = P.shop_want_force_late if i >= P.shop_weight_until else P.shop_want_force
            n_force = min(len(wpool), max(0, int(force_n)))
            self.rng.shuffle(wpool)
            offers.extend(wpool[:n_force])
            rest = [r for r in pool if r not in offers]
            # weight want relics higher
            def pick_weighted(cands):
                if not cands: return None
                weights=[]
                w_set = P.shop_set_weight_early if i < P.shop_weight_until else P.shop_set_weight
                for r in cands:
                    w = w_set if r in want else 1.0
                    weights.append(w)
                tot=sum(weights); x=self.rng.random()*tot; acc=0.0
                for r,w in zip(cands,weights):
                    acc+=w
                    if x<=acc: return r
                return cands[-1]
            while len(offers) < min(P.shop_slots, len(pool)) and rest:
                r = pick_weighted(rest)
                offers.append(r); rest.remove(r)
            got = [r for r in want if r in offers]
            if getattr(P, "dual_focus", False):
                _os = self._order_sets()
                if len(_os) >= 2 and not any(self.B.S.get(k, 0) >= 4 for k in _os):
                    _cnt = {k: self.B.S.get(k, 0) for k in _os}; _mx = max(_cnt.values())
                    if _mx >= 1:
                        _lead = [k for k in _os if _cnt[k] == _mx]
                        got = [r for r in got if any(r in self.data.sets[k] for k in _lead)]  # v2z5 AI: 双套先专心凑领先的一套
            bought = False
            for r in got:
                if len(self.R) >= P.relic_slots: break   # v2z5r6 修：同一次进店连买多件时也不超过 8 格
                pr = self._relic_price(r)
                if self.iron - pr >= reserve:
                    self.iron -= pr; self.m["spent_relic_iron"] += pr; self.R.add(r); bought = True
                    if "first_buy_vill" not in self.m: self.m["first_buy_vill"] = i
                    want = [x for x in want if x != r]
            if bought:
                self.B = Build(self.R, data, P)
                self._apply_jiancheng_quota()
                self._track_sets(i)
                if not want: return
                # keep shopping same villager if iron remains
                continue
            if P.refresh_mode == "heat":
                base_r = float(getattr(P, "refresh_base", None) or P.refresh_first)
                frac = float(getattr(P, "refresh_last_frac_heat", 0.0) or 0.0)
                if frac > 0:
                    base_r = max(base_r, frac * float(self.m.get("last_sale", 0.0) or 0.0))
                vill_index = max(0, int(self.m.get("vill", 1) or 1) - 1)  # 0-based per 铸剑
                boost = float(getattr(P, "refresh_villager_boost", 0.0) or 0.0)
                growth_eff = float(P.refresh_growth) + boost * float(vill_index)
                if growth_eff < 1.0: growth_eff = 1.0
                c = math.ceil(base_r * (growth_eff ** float(self.refresh_heat)))
            elif P.refresh_mode == "last_sale":
                base_r = max(P.refresh_first, P.refresh_last_frac * self.m["last_sale"])
                c = math.ceil(base_r * P.refresh_growth ** self.refresh_n)
            elif P.refresh_mode == "max5000":
                base_r = max(5000.0, P.refresh_first)
                c = math.ceil(base_r * P.refresh_growth ** self.refresh_n)
            else:
                base_r = P.refresh_first
                c = math.ceil(base_r * P.refresh_growth ** self.refresh_n)
            can_buy = self.iron >= min(self._relic_price(r) for r in want) + reserve
            free = self.refresh_n < P.refresh_free
            tok = (not free) and P.voucher_refresh and "voucher" in self.R and self.st.get("vtok", 0) > 0  # v2z3 voucher
            _rgf = getattr(P, "refresh_gold_frac", None)
            if tries < P.refresh_max_per_villager and can_buy and (free or tok or (self.gold >= c and (_rgf is None or c <= _rgf * self.gold))):
                if tok:
                    self.st["vtok"] -= 1; self.m["vr_voucher"] = self.m.get("vr_voucher", 0) + 1
                elif not free:
                    self.gold -= c; self.m["gold_refresh"] += c
                    _dd = self.m.setdefault("spend_day", {}); _k = (self.m.get("vill", 0), "ref"); _dd[_k] = _dd.get(_k, 0.0) + c
                    if P.hook_iron and "hook" in self.R and self.st.get("hook_n", 0) < P.hook_iron[1]:  # v2z3 hook
                        self.st["hook_n"] = self.st.get("hook_n", 0) + 1; self.st["hook_pend"] = self.st.get("hook_pend", 0) + P.hook_iron[0]
                if P.refresh_mode == "heat":
                    self.refresh_heat = float(self.refresh_heat) + 1.0  # free/tok/paid: +1 only (铸剑定稿)
                    self.m["refresh_heat_end"] = self.refresh_heat
                self.refresh_n += 1; self.m["refreshes"] += 1; tries += 1
                continue
            return

    def _order_sets(self):
        """v2v: sets the build order targets at ≥4 pieces."""
        if not hasattr(self, "_osets"):
            o = set(self.order)
            self._osets = [k for k, mem in self.data.sets.items() if len(o & mem) >= 4]
        return self._osets

    def _relic_price(self, r):
        base = self.data.price.get(r, 2)
        # v2y: per-set extra iron on that set's relic pieces (shop price, applies to any build buying them)
        ex_map = getattr(self.P, "set_relic_iron_extra", None) or {}
        extra = sum(int(n) for k, n in ex_map.items() if n and r in self.data.sets.get(k, ()))
        extra += int((getattr(self.P, "relic_iron_extra", None) or {}).get(r, 0))  # v2y per-piece extra
        os_ = self._order_sets()
        mode = getattr(self.P, "set_relic_iron_extra_dual_mode", "stack") or "stack"
        if extra and mode == "off" and len(os_) >= 2:
            extra = 0  # contrast: set extra not applied in dual-target builds
        d = int(getattr(self.P, "dual_second_set_iron_discount", 0) or 0)
        dual_add = 0
        if d != 0:  # v2w: d<0 = surcharge on second-set pieces
            if len(os_) >= 2:
                full = [k for k in os_ if self.B.S.get(k, 0) >= 4]
                if full and any(r in self.data.sets[k] and self.B.S.get(k, 0) < 4 for k in os_):
                    dual_add = -d
                    wv = getattr(self.P, "dual_surcharge_waive_if_full", None) or []
                    if any(k in wv for k in full):
                        dual_add = 0  # v2z1: waived once a listed set is full
        if dual_add:
            add = max(extra, dual_add) if mode == "max" else extra + dual_add
            return max(1, base + add)
        return max(1, base + extra) if extra else base

    def _track_sets(self, i):
        """v2v diag: villager index when 1st/2nd targeted set reaches 4."""
        nf = sum(1 for k in self._order_sets() if self.B.S.get(k, 0) >= 4)
        if nf >= 1 and self.m.get("vill_set1") is None:
            self.m["vill_set1"] = i
        if nf >= 2 and self.m.get("vill_set2") is None:
            self.m["vill_set2"] = i

    def merchant_m(self, n, mode=None):
        """Merchant cumulative multiplier on purchase index n (before buy).
        v2g / strict: ×1.5 / ×3 / ×4 → [1, 1.5, 4.5, 13.5, 54, 216, ...]
        v2g_contrast: one ×1.5, one ×3, then ×4 → [1, 1.5, 4.5, 18, 72, ...]
        soft / v2l: ×1.2 / ×1.8 / ×2.5 → [1, 1.2, 2.16, 5.4, 13.5, 33.75, ...]
        mid / v2m: ×1.35 / ×2.2 / ×3.0 → [1, 1.35, 2.97, 8.91, 26.73, ...]
        v2f: ×1.5×3 then late^(n-2) from 2.25.
        """
        if n <= 0:
            return 1.0
        if mode is None:
            mode = getattr(self.P, "merchant_m_mode", "v2g") or "v2g"
        if isinstance(mode, str) and mode.startswith("geo"):
            return float(mode[3:]) ** n  # special-sword: geometric growth per repeat purchase
        if mode == "v2f":
            if n == 1:
                return 1.5
            if n == 2:
                return 2.25
            late = getattr(self.P, "merchant_late_mult", 4.0)
            return 2.25 * (late ** (n - 2))
        if mode in ("soft", "v2l"):
            # milder steps than v2g: ×1.2, ×1.8, then ×2.5 thereafter
            if n == 1:
                return 1.2
            if n == 2:
                return 2.16
            if n == 3:
                return 5.4
            return 5.4 * (2.5 ** (n - 3))
        if mode in ("mid", "v2m"):
            # v2m default: between soft and strict — ×1.35, ×2.2, then ×3.0
            if n == 1:
                return 1.35
            if n == 2:
                return 2.97
            if n == 3:
                return 8.91
            return 8.91 * (3.0 ** (n - 3))
        if mode == "v2g_contrast":
            # slow window only n=0 (one ×1.5), then one ×3, then ×4
            if n == 1:
                return 1.5
            if n == 2:
                return 4.5
            return 4.5 * (4.0 ** (n - 2))
        # v2g / strict primary
        if n == 1:
            return 1.5
        if n == 2:
            return 4.5
        if n == 3:
            return 13.5
        return 13.5 * (4.0 ** (n - 3))

    def merchant_price(self, kind=None):
        P = self.P
        # v2h lock: P=max(floor, a_low*last, a_high*run_max)*m(n)
        # a_low always; a_high unlocks after any sold L>=unlock (else a_high=a_low)
        # legacy flat/segmented: if merchant_a_high unset path via merchant_frac / late_frac
        # v2l: optional separate n for iron vs rewind (merchant_separate_n)
        a_low = getattr(P, "merchant_a_low", None)
        if a_low is None:
            # legacy v2g path
            frac = P.merchant_frac
            late_frac = getattr(P, "merchant_late_frac", None)
            if late_frac is not None and self.m.get("vill", 0) >= 9:
                frac = late_frac
            a_low = frac
            a_high = frac
        else:
            unlock = getattr(P, "merchant_a_high_unlock_level", 90)
            sold = self.m.get("sold") or []
            unlocked = any(L >= unlock for L in sold) or (max(sold) if sold else -1) >= unlock
            a_high = (getattr(P, "merchant_a_high", a_low) if unlocked else a_low)
            # optional segmented late_frac still overrides both when set (v2g compat)
            late_frac = getattr(P, "merchant_late_frac", None)
            if late_frac is not None and self.m.get("vill", 0) >= 9:
                a_low = late_frac
                a_high = late_frac
        floor = self._effective_merchant_floor()
        base = max(floor,
                   a_low * self.m["last_sale"],
                   a_high * self.m.get("max_sale", 0.0))
        separate = getattr(P, "merchant_separate_n", False)
        _stb = getattr(P, "merchant_special_table", None)
        if kind == "special" and _stb:
            d = self.m.get("vill", 0); base = _stb.get(d, _stb.get(str(d)))
            if base is None: return float("inf")
            return float(base) * float(P.merchant_special_mult) ** self.m.get("merchant_special", 0) * self.B.merchant_mult
        _sfx = getattr(P, "merchant_special_fixed", None)
        if kind == "special" and _sfx:
            return float(_sfx[0]) * float(_sfx[1]) ** self.m.get("merchant_special", 0) * self.B.merchant_mult
        _fm = getattr(P, "merchant_iron_formula", None)
        if kind == "iron" and _fm:
            B0, Bg, g0, gs, d0 = _fm; dd = self.m.get("vill", 0) - d0
            _bt = getattr(P, "merchant_iron_B_table", None)
            Bd = float(_bt[self.m.get("vill", 0)]) if (_bt and self.m.get("vill", 0) in _bt) else B0 * Bg ** dd
            return float(Bd * (g0 + gs * dd) ** self._visit_iron()) * self.B.merchant_mult
        _lad = getattr(P, "merchant_iron_ladder", None)
        if kind == "iron" and _lad:
            j = self._visit_key() + self._visit_iron()
            pr = _lad[j] if j < len(_lad) else _lad[-1] * (P.merchant_ladder_tail_g ** (j - len(_lad) + 1))
            return float(pr) * self.B.merchant_mult
        if kind == "iron" and getattr(P, "merchant_visit_stock", None):
            n = self._visit_iron()
            mode = getattr(P, "merchant_iron_m_mode", None) or getattr(P, "merchant_m_mode", "v2g")
        elif separate and kind == "iron":
            n = self.m.get("merchant_iron", 0) - self.silver_skip
            mode = getattr(P, "merchant_m_mode", "v2g")
        elif separate and kind == "rewind":
            n = self.m.get("merchant_rewind", 0)
            mode = getattr(P, "merchant_rewind_m_mode", None) or getattr(P, "merchant_m_mode", "v2g")
        elif separate and kind == "special":
            # specials escalate on their own buy count; use iron m_mode
            n = self.m.get("merchant_special", 0)
            mode = getattr(P, "merchant_special_m_mode", None) or getattr(P, "merchant_m_mode", "v2g")
        else:
            n = self.mbought - self.silver_skip
            mode = getattr(P, "merchant_m_mode", "v2g")
        if kind == "special" and getattr(P, "merchant_special_floor", None):
            base = max(base, float(P.merchant_special_floor))
        price = base * self.merchant_m(n, mode=mode) * self.B.merchant_mult
        if kind == "special":
            price *= float(getattr(P, "merchant_special_price_mult", 2.0) or 2.0)
        return price

    def _pay_merchant(self, c, kind):
        """kind: 'iron' | 'rewind' | 'special'. Segment by villager: 1–8 early, 9+ late."""
        self.gold -= c
        self.m["gold_merchant"] += c
        _dd = self.m.setdefault("spend_day", {}); _k = (self.m.get("vill", 0), "iron" if kind == "iron" else "other"); _dd[_k] = _dd.get(_k, 0.0) + c
        self.mbought += 1
        early = self.m.get("vill", 0) <= 8
        if early:
            self.m["gold_merchant_early"] += c
        else:
            self.m["gold_merchant_late"] += c
        if kind == "iron":
            if 'silverpermit' in self.B.fz and self.silver_vis != self.m.get('vill', 0):
                self.silver_vis = self.m.get('vill', 0); self.silver_skip += 1
            self.iron += 1
            self.m["merchant_iron"] += 1
            _idd = self.m.setdefault("iron_days", {}); _idd[self.m.get("vill", 0)] = _idd.get(self.m.get("vill", 0), 0) + 1
            if getattr(self.P, "merchant_visit_stock", None): self._visit_iron(); self.st["vis_n"] += 1
            if early:
                self.m["gold_merchant_iron_early"] += c
                self.m["merchant_iron_early"] += 1
            else:
                self.m["gold_merchant_iron_late"] += c
                self.m["merchant_iron_late"] += 1
        elif kind == "rewind":
            self.rewind += 1
            self.m["merchant_rewind"] = self.m.get("merchant_rewind", 0) + 1
            self.m["gold_merchant_rewind"] += c
            self.last_bad_strike = False  # consumed the buy signal
        elif kind == "special":
            # spawn a special sword onto rack (no iron cost); ×2 innate into M if special_counts_to_M
            self.m["merchant_special"] = self.m.get("merchant_special", 0) + 1
            self.m.setdefault("special_day", self.m.get("vill", 0))
            self.m["gold_merchant_special"] = self.m.get("gold_merchant_special", 0.0) + c
            cap = 1 + self.P.rack
            if len(self.swords) < cap:
                scar_n = self.P.shanghen_set4_convert if self.B.S.get("伤痕", 0) >= 4 else 0
                self._refresh_jiancheng_convert()
                self.swords.append(Sword(0, 0, special=True, scar_conv=scar_n))
            else:
                # rack full: mark next new_sword as special voucher
                self.st["pending_special"] = self.st.get("pending_special", 0) + 1

    def _want_rewind(self):
        """v2j AI: buy rewind only if inventory empty, under run cap, sword≥min_L,
        and (unless disabled) last strike was break/damage. Shares m(n)/a_high with iron."""
        P = self.P
        rewind_cap = getattr(P, "merchant_rewind_cap", 2)
        if rewind_cap is not None and self.m.get("merchant_rewind", 0) >= rewind_cap:
            return False
        if self.rewind > 0:
            return False  # already holding a charge
        big = max((s.L for s in self.swords), default=0)
        min_L = getattr(P, "merchant_rewind_min_level", 50)
        if big < min_L:
            return False
        if getattr(P, "merchant_rewind_require_bad", True) and not self.last_bad_strike:
            return False
        return True

    def _a_high_unlocked(self):
        unlock = getattr(self.P, "merchant_a_high_unlock_level", 90)
        sold = self.m.get("sold") or []
        return any(L >= unlock for L in sold)

    def _tier(self):
        if self.P.no_sets:
            n = self.B.n_ab; return 4 if n >= 4 else (2 if n >= 2 else 0)
        v = max([self.B.S.get(k, 0) for k in self._order_sets()] or [0])
        return 4 if v >= 4 else (2 if v >= 2 else 0)

    def _ev_new_sword(self, special=False):
        """v2z5r2: 当前档开一把新剑的期望卖价（查表；满4件 = P99×V(99,M)）。"""
        e0, e2, p99 = self.P.merchant_ev_tiers
        t = self._tier()
        if t >= 4:
            M = M_of(Sword(99), self.B, self.P)
            if special: M = min(self.B.m_cap, M * self.P.special_innate_mult)
            return p99 * self.data.value(99, M)
        base = e2 if t >= 2 else e0
        return base * (self.P.special_innate_mult if special else 1.0)

    def _refresh_price_peek(self):
        """v2z5: 当前 heat 下下一次付费刷新价（只读）。非 heat 模式返回 0。"""
        P = self.P
        if P.refresh_mode != "heat": return 0.0
        base_r = float(getattr(P, "refresh_base", None) or P.refresh_first)
        vi = max(0, int(self.m.get("vill", 1) or 1) - 1)
        g = max(1.0, float(P.refresh_growth) + float(getattr(P, "refresh_villager_boost", 0.0) or 0.0) * vi)
        return math.ceil(base_r * g ** float(self.refresh_heat))

    def _fx(self, k, d):
        fx = getattr(self.P, "relic_fx", None)
        return fx.get(k, d) if fx else d

    def _visit_key(self):
        i = self.m.get("vill", 0)
        e = self.P.merchant_every
        if getattr(self.P, "merchant_visit_mode", "pair") == "day":
            return 2 * ((i - 1) // e) + (0 if i % e == e - 1 else 1)
        return (i - 1) // e

    def _visit_iron(self):
        k = self._visit_key()
        if self.st.get("vis_k") != k: self.st["vis_k"] = k; self.st["vis_n"] = 0
        return self.st["vis_n"]

    def _want_iron(self):
        """Iron AI: optional hard cap; before ≥+90 buy toward early_max (2–3) when stock low;
        after ≥+90 only if iron stock==0 (if late_only_empty). Optional budget hat vs earned.
        v2l: soft m + separate n; default no hard cap (cap≥99)."""
        P = self.P
        _vs = getattr(P, "merchant_visit_stock", None)
        if _vs:
            if self._visit_iron() >= _vs: return False
        iron_cap = getattr(P, "merchant_iron_cap", 3)
        iron_buys = self.m.get("merchant_iron", 0)
        if iron_cap is not None and iron_buys >= iron_cap:
            return False
        # budget hat: cumulative iron gold / earned
        bud = getattr(P, "merchant_iron_budget_frac", None)
        if bud is not None:
            earned = self.m.get("earned", 0.0) or 0.0
            if earned > 0:
                ig = (self.m.get("gold_merchant_iron_early", 0.0)
                      + self.m.get("gold_merchant_iron_late", 0.0))
                if ig / earned > bud:
                    return False
        if getattr(P, "merchant_iron_ai", None) == "greedy":
            return True
        if getattr(P, "merchant_iron_ai", None) == "ev":
            c = self.merchant_price("iron")
            if c > float(getattr(P, "merchant_iron_value_k", 0.5)) * self._ev_new_sword(): return False
            return self.gold - c >= self._refresh_price_peek()
        if getattr(P, "merchant_iron_ai", None) == "value":
            # v2z5 价值买铁：本块价 ≤ k × 近 3 次卖剑均价（≈一把新剑期望净收益），且买后金币仍够下一次刷新
            sd = self.m.get("sold_detail") or []
            if not sd: return False
            rec = sum(x["gold"] for x in sd[-3:]) / len(sd[-3:])
            c = self.merchant_price("iron")
            if c > float(getattr(P, "merchant_iron_value_k", 1.0)) * rec: return False
            return self.gold - c >= self._refresh_price_peek()  # v2z5 AI: 有货且价格 ≤ buy_frac·持有金币 就买（受预算帽）；不设库存目标
        late_only_empty = getattr(P, "merchant_iron_late_only_empty", False)
        if self._a_high_unlocked():
            late_stock = getattr(P, "merchant_iron_late_stock", None)
            if late_stock is not None:
                # v2u econ contrast: refill toward late stock target 2–3 (A1b-style; not win knife)
                return self.iron < int(late_stock)
            if late_only_empty:
                return self.iron == 0
        early_max = getattr(P, "merchant_iron_early_max", 3)
        # early_max only binds when finite; None/≥99 = no early purchase count limit
        if early_max is not None and early_max < 99 and iron_buys >= early_max:
            return False
        # cheap pre-+90: fill toward reserve+1 (enough for 2–3 buys at 5%)
        return self.iron < P.forge_iron_reserve + 1

    def _want_special(self):
        """v2n bank-special: buy special×2 swords after set assembled, under cap, if rack space."""
        P = self.P
        if getattr(P, "merchant_special_ai", None) == "ev":
            if self.m.get("merchant_special", 0) >= P.merchant_special_cap: return False
            if any(getattr(s, "special", False) and s.L < 99 for s in self.swords): return False
            c = self.merchant_price("special")
            return c < self._ev_new_sword(special=True) and self.gold >= c
        if not getattr(P, "merchant_special_enabled", False):
            return False
        cap = getattr(P, "merchant_special_cap", 4)
        if self.m.get("merchant_special", 0) >= cap:
            return False
        if getattr(P, "merchant_special_after_set", True):
            primary_done = (not any(r not in self.R for r in self.order)) if self.order else (len(self.R) >= 4)
            if not primary_done:
                return False
        # need rack room or pending voucher ok if rack full (voucher path)
        # prefer buying when we don't already hold an unfinished special
        holding_spec = any(getattr(s, "special", False) and s.L < 99 for s in self.swords)
        if holding_spec:
            return False
        if getattr(P, "merchant_special_ev_gate", False):
            M = M_of(Sword(99), self.B, P)
            obs = [d["M"] for d in (self.m.get("sold_detail") or []) if d["L"] >= 99 and not d.get("special")]
            if obs:
                M = max(M, sorted(obs)[len(obs) // 2])  # player sees what its +99s actually sold at
            gain = self.data.value(99, min(self.B.m_cap, M * P.special_innate_mult)) - self.data.value(99, M)
            if self.merchant_price("special") > P.merchant_special_ev_k * P.merchant_special_ev_p * gain:
                self.m["special_ev_declined"] = self.m.get("special_ev_declined", 0) + 1
                return False
        return True

    def merchant(self):
        P = self.P
        while self.mbought < P.merchant_cap:
            want_iron = self._want_iron()
            want_rw = self._want_rewind()
            want_sp = self._want_special()
            # price depends on kind when separate_n (different counters / m modes)
            c_iron = self.merchant_price("iron") if want_iron else None
            c_rw = self.merchant_price("rewind") if want_rw else None
            c_sp = self.merchant_price("special") if want_sp else None
            # affordability: reserve-critical uses looser frac; else buy_frac (early override possible)
            critical = want_iron and self.iron == 0
            frac = self._effective_buy_frac(critical=critical)
            buy_frac = self._effective_buy_frac(critical=False)
            # priority: empty-stock iron > special (bank M) > reactive rewind > early top-up iron
            _evm = getattr(P, "merchant_iron_ai", None) == "ev"
            if _evm and want_iron and c_iron is not None and c_iron <= self.gold:
                self._pay_merchant(c_iron, "iron"); continue
            if want_iron and self.iron == 0 and c_iron is not None and c_iron <= self.gold * frac:
                self._pay_merchant(c_iron, "iron"); continue
            if want_sp and c_sp is not None and (c_sp <= self.gold * buy_frac or (getattr(P, "merchant_special_ai", None) == "ev" and c_sp <= self.gold)):
                self._pay_merchant(c_sp, "special"); continue
            if want_rw and c_rw is not None and c_rw <= self.gold * buy_frac:
                self._pay_merchant(c_rw, "rewind"); continue
            if want_iron and c_iron is not None and c_iron <= self.gold * frac:
                self._pay_merchant(c_iron, "iron"); continue
            return

    # ---- 主循环（策略同 sim_v2.run：小剑满足需求、大剑冲 +99；交 +99 优先，否则交满足需求的最低剑） ----
    def demand(self, i):
        P = self.P
        _do = getattr(P, "demand_override", None)
        if _do and i in _do: return int(_do[i])   # v2z5r7: 逐天等级需求覆盖
        if i <= 8:
            L = P.early_demand_lo + round((i - 1) * (P.early_demand_hi - P.early_demand_lo) / 7)
        elif i <= 15:
            L = P.mid_demand_lo + round((i - 9) * (P.mid_demand_hi - P.mid_demand_lo) / 6)
        else:
            base = P.late_demand_floor + round((i - 16) * (P.late_demand_top - P.late_demand_floor) / 9)
            L = int(round(base * P.late_demand_scale))
        return min(99, max(0, int(L)))

    def _starter_best(self, offers, fallback):
        """v2z2 player start pick (deterministic priority):
        1) an offer in the build order (earliest in order);
        2) an offer that is a member of a targeted set (sets the order fills to 4; set iteration order) - counts toward that set;
        3) the shop fill list for this build's policy: value-first builds (入神/大成 → value) take
           value list then forge list; forge-first builds (伤痕/坚城) take forge list then value
           (same lists/order as shop() fill); 4) else the random pick (fallback)."""
        P = self.P
        for r in self.order:
            if r in offers:
                return r
        osets = self._order_sets()
        for k in osets:
            mem = self.data.sets.get(k, set())
            for r in offers:
                if r in mem:
                    return r
        pol = getattr(P, "shop_fill_policy", None) or {}
        value_first = any(pol.get(k) == "value" for k in osets)
        pref = (STARTER_VALUE + STARTER_FORGE) if value_first else (STARTER_FORGE + STARTER_VALUE)
        for r in pref:
            if r in offers:
                return r
        return fallback

    def starter(self):
        """1-of-3 free pick from 1-iron pool (random; optional want bias via starter_want_bias)."""
        P, data = self.P, self.data
        if not P.starter_pick or self.R:
            return
        self.m["starter"] = None
        pool = [r for r in data.pool if r not in self.R]
        if P.starter_1iron_only:
            one = [r for r in pool if data.price.get(r, 99) <= 1]
            if one: pool = one
        want = [r for r in self.order if r in pool]
        offers = []
        pool2 = list(pool)
        if getattr(P, 'starter_want_bias', False) and want:
            offers.append(want[0]); pool2 = [r for r in pool2 if r != want[0]]
        while len(offers) < min(3, len(pool)) and pool2:
            offers.append(pool2.pop(self.rng.randrange(len(pool2))))
        if getattr(P, 'starter_want_bias', False):
            pick = next((r for r in self.order if r in offers), offers[0])
        else:
            pick = offers[self.rng.randrange(len(offers))]
            if getattr(P, "starter_pick_policy", "random") == "best":
                pick = self._starter_best(offers, pick)  # rng draw above kept so the downstream stream is identical
        if getattr(P, "dual_skip_offbuild_starter", False) and len(self.order) >= P.relic_slots and pick not in self.order:
            inorder = [r for r in offers if r in self.order]
            if not inorder:
                self.m["starter"] = "declined"
                return
            pick = inorder[0]
        self.m["starter"] = pick
        self.R.add(pick)
        self.B = Build(self.R, data, P)
        self._track_sets(0)

    def play(self):
        P, data = self.P, self.data
        if P.starter_pick and not self.R:
            self.starter()
        cap = 1 + P.rack
        for i in range(1, P.villagers + 1):
            if i > 1 and getattr(P, "refresh_mode", "flat") == "heat":
                self.refresh_heat = max(0.0, float(self.refresh_heat) - float(getattr(P, "refresh_decay", 0.0) or 0.0))
            self.m["vill"] = i
            _inc = self.rng.randint(P.iron_min, P.iron_max)
            if self.B.iron_every3 and i % 3 == 0: _inc += 1
            _vr = 0  # v2z3 villager relics (income outside the purse roll; rng untouched)
            si = P.supply_iron
            if si and "supply" in self.R and i % si[0] == 0 and (len(si) < 3 or self.st.get("sup_n", 0) < si[2]):
                _vr += si[1]; self.st["sup_n"] = self.st.get("sup_n", 0) + si[1]
            if self.st.get("hook_pend", 0): _vr += self.st["hook_pend"]; self.st["hook_pend"] = 0
            if P.voucher_refresh and "voucher" in self.R and i > 1 and (i - 1) % P.voucher_refresh[0] == 0:
                self.st["vtok"] = min(P.voucher_refresh[1], self.st.get("vtok", 0) + 1)
            if _vr: _inc += _vr; self.m["vr_iron"] = self.m.get("vr_iron", 0) + _vr
            _eb = getattr(P, "early_iron_bonus", None)
            if _eb and i <= _eb[0]: _inc += _eb[1]; self.m["early_bonus_iron"] = self.m.get("early_bonus_iron", 0) + _eb[1]
            self.st["lbr_n"] = 0
            _sw0 = self.m.get("iron_swords", 0); _br0 = self.m["breaks"]; _st0 = self.m["strikes"]
            self.iron += _inc
            self.m["iron_income"] = self.m.get("iron_income", 0) + _inc
            self.shop(i)
            Lreq = self.demand(i)
            vreq = None
            if i >= 16 and self.rng.random() < P.req_value_frac:
                vreq = data.value(Lreq)
            if "letter" in self.R and (P.letter_demand_mult or 1.0) != 1.0:  # v2z3 letter
                Lreq = int(math.floor(Lreq * P.letter_demand_mult)); vreq = None if vreq is None else vreq * P.letter_demand_mult
            if self.st.get("rc_pend", 0):  # v2z3 royalchange (level demand only)
                if vreq is None: Lreq = max(0, Lreq - self.st["rc_pend"]); self.m["vr_royalchange"] = self.m.get("vr_royalchange", 0) + 1
                self.st["rc_pend"] = 0
            ok = lambda s: (s.L >= Lreq) if vreq is None else (data.value(s.L, M_of(s, self.B, P)) >= vreq)
            T = 0.0
            # assemble phase: stop at demand until 入神>=4 (or 6 relics)
            # assemble until primary order complete; 价值-first also waits for light forge help
            primary_done = (not any(r not in self.R for r in self.order)) if self.order else (len(self.R) >= 4)
            if not primary_done and getattr(P, "assemble_done_when_full", False) and len(self.R) >= P.relic_slots:
                primary_done = True
            if not primary_done and P.no_sets and self.B.n_ab >= 4:
                primary_done = True  # v2z5r3: 4 件防碎即开冲
            if not primary_done and getattr(P, "assemble_done_on_set4", False) and any(self.B.S.get(k, 0) >= 4 for k in self._order_sets()):
                primary_done = True  # v2z5 AI: 任一目标套满4件即开始冲（双套继续顺手买第二套）
            self.m["assembling_vills"] = self.m.get("assembling_vills", 0) + int(not primary_done)
            need_forge = primary_done and self.B.S.get("价值", 0) >= 4 and self.B.S.get("入神", 0) < 2
            assembling = (not primary_done) or need_forge
            if self.iron < P.forge_iron_reserve and self.gold > 0 and (not getattr(P, "fz_gate_emergency", False) or (i % P.merchant_every == 0 or i % P.merchant_every > P.merchant_every - P.merchant_presence)):
                self.merchant()
            _winsw = None
            while T < P.patience:
                if getattr(P, "win_sell", False):
                    _wc = [s for s in self.swords if data.value(s.L, M_of(s, self.B, P)) + self.gold >= P.target]
                    if _wc: _winsw = min(_wc, key=lambda s: s.L); break  # v2z5r3 AI: 够通关就卖
                ws = sorted(self.swords, key=lambda s: -s.L)
                big = ws[0] if ws else None
                # ensure a delivery sword exists when pushing
                ok_any = [s for s in self.swords if ok(s)]
                if assembling and ok_any:
                    break
                tgt = None
                cap = 1 + P.rack
                if assembling:
                    # only forge until demand on a cheap sword
                    if not ok_any:
                        if big is None and self.iron > 0:
                            tgt = self.new_sword()
                        elif big is not None and not ok(big):
                            tgt = big
                        elif len(self.swords) < cap and self.iron > 0:
                            tgt = self.new_sword()
                else:
                    # push phase: keep one ok delivery sword if possible; push the other
                    # v2n bank_special_push: prefer unfinished specials toward +99 (×2 M)
                    delivery = ok_any[0] if ok_any else None
                    push_cands = [s for s in self.swords if s is not delivery]
                    bank_sp = getattr(P, "bank_special_push", False)
                    if bank_sp:
                        specs = [s for s in self.swords if getattr(s, "special", False) and s.L < 99]
                        if specs:
                            # push highest special first
                            cand = max(specs, key=lambda s: s.L)
                            if not (delivery is cand and self.iron <= 0 and ok(cand)):
                                tgt = cand
                    if tgt is None and big is not None and big.L < 99 and (delivery is None or big is not delivery or self.iron > 0 or len(self.swords) > 1):
                        # do not greed-break the sole delivery sword if no iron to replace
                        if delivery is big and self.iron <= 0 and ok(big):
                            tgt = None
                        else:
                            tgt = big if big.L < 99 else None
                    if tgt is None and len(self.swords) < cap and self.iron > 0:
                        tgt = self.new_sword()
                    if tgt is None and push_cands:
                        if bank_sp:
                            spc = [s for s in push_cands if getattr(s, "special", False) and s.L < 99]
                            pc = max(spc or push_cands, key=lambda s: s.L)
                        else:
                            pc = max(push_cands, key=lambda s: s.L)
                        if pc.L < 99:
                            tgt = pc
                if tgt is None:
                    break
                if tgt.L >= 99:
                    break
                snap = tgt.copy() if (self.rewind and tgt.L >= 60) else None
                dt, b = self.strike(tgt); T += dt; self.m["strikes"] += 1
                if b:
                    if snap is not None:
                        self.rewind -= 1; self.m["rewinds"] += 1
                        idx = self.swords.index(tgt); self.swords[idx] = snap
                        continue
                    self.on_break(tgt); self.swords.remove(tgt)
                    if self.iron < P.forge_iron_reserve and (not getattr(P, "fz_gate_emergency", False) or (i % P.merchant_every == 0 or i % P.merchant_every > P.merchant_every - P.merchant_presence)):
                        self.merchant()
            # 交剑（无银行自限：有+99先交+99，否则交满足需求的最低非顶剑）
            # v2n: if bank_special_push, prefer special +99 so ×2 lands in sold M
            q = sorted([s for s in self.swords if ok(s)], key=lambda s: s.L)
            if _winsw is None and getattr(P, "win_sell", False):
                _wc = [s for s in self.swords if data.value(s.L, M_of(s, self.B, P)) + self.gold >= P.target]
                if _wc: _winsw = min(_wc, key=lambda s: s.L)
            if getattr(P, "bank_special_push", False):
                hand = next((s for s in self.swords if s.L >= 99 and getattr(s, "special", False)), None)
                if hand is None:
                    hand = next((s for s in self.swords if s.L >= 99), None)
            else:
                hand = next((s for s in self.swords if s.L >= 99), None)
            if _winsw is not None: hand = _winsw
            if hand is None and q:
                top = max(self.swords, key=lambda s: s.L)
                nontop = [s for s in q if s is not top]
                _bk=int(getattr(P,"bank_keep_level",80)); _br=getattr(P,"bank_release_gold",None)
                _hold = top.L >= _bk and self.stars == 3 and (_br is None or self.gold < float(_br))
                hand = nontop[0] if nontop else (None if _hold else top)
            if hand is not None:
                self.swords.remove(hand)
                Mm = M_of(hand, self.B, P)
                price = data.value(hand.L, Mm)
                self.gold += price; self.m["earned"] += price; self.m["last_sale"] = price; self.m["max_sale"] = max(self.m.get("max_sale",0.0), price)
                self.m["sold"].append(hand.L); self.m["n99"] += hand.L >= 99
                self.m["n70"] += hand.L >= 70; self.m["n90"] += hand.L >= 90
                if hand.L >= 99 and getattr(hand, "special", False):
                    self.m["n99_special"] = self.m.get("n99_special", 0) + 1
                self.m.setdefault("sold_M", []).append(Mm)
                # demand-eaten: ≥+70 sold below +99 near demand gate or while still assembling
                gap = hand.L - Lreq
                eaten = (hand.L >= 70 and hand.L < 99 and (assembling or gap < 15))
                if eaten:
                    self.m["eaten_ge70"] += 1
                if hand.L >= 90:
                    self.m["gold_ge90"] += price
                elif hand.L >= 30:
                    self.m["gold_mid"] += price
                self.m.setdefault("sold_detail", []).append(dict(
                    L=hand.L, M=Mm, gold=price, Lreq=Lreq, vill=i,
                    assembling=bool(assembling), gap=gap, eaten=bool(eaten),
                    special=bool(getattr(hand, "special", False)), tier=(self.B.n_ab if P.no_sets else (max(self.B.S.values()) if self.B.S else 0)), pool=float(M_of(hand, self.B, P))))
                if "hearth" in self.B.R: pass  # v2z3: hearth = 不出现 (relic_not_appear), effect intentionally not implemented
                if ok(hand):  # v2z3: satisfied-villager relics
                    if P.collector_iron and "collector" in self.R:
                        self.st["coll_n"] = self.st.get("coll_n", 0) + 1
                        ci = P.collector_iron
                        if self.st["coll_n"] % ci[0] == 0 and (len(ci) < 3 or self.st.get("coll_got", 0) < ci[2]):
                            self.iron += ci[1]; self.st["coll_got"] = self.st.get("coll_got", 0) + ci[1]; self.m["vr_iron"] = self.m.get("vr_iron", 0) + ci[1]
                    if P.badge_start and "badge" in self.R: self.st["badge"] = True
                    ta = P.testament_inherit
                    if ta and "testament" in self.R and hand.L >= ta[0] and self.st.get("testa_uses", 0) < ta[2]:
                        self.st["testa"] = max(self.st.get("testa", 0), int(hand.L * ta[1]))
                    rc = P.royalchange_relief
                    if rc and "royalchange" in self.R and vreq is None and hand.L - Lreq >= rc[0]:
                        self.st["rc_pend"] = rc[1]
            else:
                self.m["unsat"] = self.m.get("unsat", 0) + 1
                if self.iron <= 0:
                    self.m["stuck"] = self.m.get("stuck", 0) + 1
                    if i <= 8: self.m["stuck_early"] = self.m.get("stuck_early", 0) + 1
                if self.st.get("badge"): self.st["badge"] = False  # v2z3 badge needs the previous villager satisfied
                self.stars -= 1
                if "mourning" in self.B.R: self.st["mourn"] += 2
                if self.stars <= 0:
                    self.m["fail"] = True; break
            self.m.setdefault("earned_by_vill", []).append(self.m["earned"])
            if i <= 6:
                self.m.setdefault("day_log", []).append((self.m.get("iron_swords", 0) - _sw0, self.iron, len(self.R), self.m["breaks"] - _br0, self.m["strikes"] - _st0))
            if self.gold >= P.target:
                self.m["win"] = True
                _sd = self.m.get("sold_detail") or []
                self.m["win_info"] = dict(vill=i, max_sold=max((d["L"] for d in _sd), default=0), last_gold=(_sd[-1]["gold"] if _sd and _sd[-1]["vill"] == i else 0.0),
                    nR=len(self.R), nab=self.B.n_ab, last_special=bool(_sd and _sd[-1]["vill"] == i and _sd[-1].get("special")), last_L=(_sd[-1]["L"] if _sd else 0), max_set=max(self.B.S.values()) if self.B.S else 0, order_full=all(r in self.R for r in self.order))
                break
            if P.merchant and (i % P.merchant_every == 0 or i % P.merchant_every > P.merchant_every - P.merchant_presence):
                self.merchant()
        self.m["final_R"] = sorted(self.R)
        self.m["iron_left"] = self.iron
        return self.m


STARTER_FORGE = ["glass", "perfectcore", "everwick", "bellows", "seal", "nail", "echo", "headless", "speed", "loop", "rivet", "cornerstone"]  # = shop() forge fill
STARTER_VALUE = ["token", "coal", "blackstone", "idol", "coin", "knot", "bell", "incense"]  # = shop() value fill


def push_one(P, data, relics, rng, start=0, post_fever=False):
    r = RunV2(P, data, relics, rng, start_full=True)
    # open-sword calib: force 1/1 corner/spine (ignore run quota from init).
    # Quota is a multi-sword shop lever; single-sword P(+99) stays ~20% calib.
    # Efficacy still applies in strike() when set.
    r.st["corner"] = P.cornerstone_uses
    r.st["spine"] = P.spine_uses
    scar_n = P.shanghen_set4_convert if r.B.S.get("伤痕", 0) >= 4 else 0
    s = Sword(start, scar_conv=scar_n); s.fev_started = post_fever; best = s.L
    r.swords = [s]
    for _ in range(20000):
        if s.L >= 99: return best, True
        _, b = r.strike(s)
        if b: return best, False
        best = max(best, s.L)
    return best, s.L >= 99


BUILDS = {
    "B0 无遗物": [],
    "S入神4": ["glass", "perfectcore", "everwick", "bellows"],
    "S稳定4": ["seal", "rivet", "cornerstone", "spine"],  # 数值锁·稳定=坚城
    "S大成功4": ["pin", "oracledie", "fork", "obsidian"],  # 数值锁·大成功=大成
    "S损伤4": ["oath", "royalseal", "scales", "crown"],  # 数值锁·损伤=伤痕
    "S价值4": ["token", "coal", "blackstone", "idol"],
    "B1 散件6件": ["nail", "seal", "glass", "everwick", "cornerstone", "echo"],
    "B2 入神4+坚城2": ["glass", "perfectcore", "everwick", "bellows", "seal", "cornerstone"],
    "B3 入神4+坚城4": ["glass", "perfectcore", "everwick", "bellows", "seal", "rivet", "cornerstone", "spine"],
    "B4 价值4+入神4(M=10)": ["token", "coal", "blackstone", "idol", "glass", "perfectcore", "everwick", "bellows"],
    "B5 大成4+坚城4": ["pin", "oracledie", "fork", "obsidian", "seal", "rivet", "cornerstone", "spine"],
    "B6 薪火4+坚城2": ["holy", "dawnsheath", "shard", "grudge", "seal", "cornerstone"],
    "B7 价值4+大成4(M=10)": ["token", "coal", "blackstone", "idol", "pin", "oracledie", "fork", "obsidian"],
}
PRIMARY_OPEN = "S入神4"
PRIMARY_CLEAR = "S价值4"
SIDE_DUAL = "B4 价值4+入神4(M=10)"


def _job(a):
    P, relics, lo, hi, start_full = a
    data = Data(P); out = []
    for i in range(lo, hi):
        rng = random.Random((P.seed * 1_000_003 + i * 7919) ^ 0x2B2B)
        out.append(RunV2(P, data, relics, rng, start_full).play())
    return out


def run_many(P, relics, runs=1000, start_full=False, pool=None, procs=8):
    step = max(1, runs // (procs * 4))
    jobs = [(P, relics, lo, min(runs, lo + step), start_full) for lo in range(0, runs, step)]
    parts = pool.map(_job, jobs) if pool else [_job(j) for j in jobs]
    return [m for p in parts for m in p]


def _pjob(a):
    P, relics, lo, hi, start, post = a
    data = Data(P); out = []
    for i in range(lo, hi):
        rng = random.Random((P.seed * 7_000_003 + i * 104729) ^ 0x7E7E)
        out.append(push_one(P, data, relics, rng, start, post))
    return out


def push_stats(P, relics, N=4000, start=0, post=False, pool=None, procs=8):
    step = max(1, N // (procs * 4))
    jobs = [(P, relics, lo, min(N, lo + step), start, post) for lo in range(0, N, step)]
    parts = pool.map(_pjob, jobs) if pool else [_pjob(j) for j in jobs]
    rows = [r for p in parts for r in p]
    n = len(rows)
    P_ = lambda X: sum(1 for g, ok in rows if ok or g >= X) / n
    return dict(p50=P_(50), p80=P_(80), p99=sum(1 for g, ok in rows if ok) / n)


def summarize(res):
    import numpy as np
    n = len(res)
    win = sum(r["win"] for r in res) / n
    fail = sum(r["fail"] for r in res) / n
    shares = [(r["gold_merchant"] + r["gold_refresh"]) / r["earned"] for r in res if r["earned"] > 0]
    wins = [r for r in res if r["win"]]
    hist = [0] * 10
    for r in res:
        for L in r["sold"]:
            hist[min(9, L // 10)] += 1
    fine = [0] * 100
    for r in res:
        for L in r["sold"]:
            fine[L] += 1
    def _med_frac(key_fn):
        xs = [key_fn(r) / r["earned"] for r in res if r["earned"] > 0]
        return float(np.median(xs)) if xs else 0.0
    iron_gold = lambda r: r.get("gold_merchant_iron_early", 0.0) + r.get("gold_merchant_iron_late", 0.0)
    rewind_gold = lambda r: r.get("gold_merchant_rewind", 0.0)
    # other = merchant − iron − rewind (should be ~0 if only iron+rewind sold)
    other_merch = lambda r: max(0.0, r["gold_merchant"] - iron_gold(r) - rewind_gold(r))
    return dict(win=win, fail=fail, spend_med=float(np.median(shares)) if shares else 0.0,
                spend_win_med=float(np.median([(r["gold_merchant"] + r["gold_refresh"]) / r["earned"] for r in wins])) if wins else float("nan"),
                merchant_med=float(np.median([r["gold_merchant"] / r["earned"] for r in res if r["earned"] > 0])) if shares else 0.0,
                refresh_med=_med_frac(lambda r: r["gold_refresh"]),
                spend_iron_med=_med_frac(iron_gold),
                spend_rewind_med=_med_frac(rewind_gold),
                spend_other_med=_med_frac(other_merch),
                spend_refresh_med=_med_frac(lambda r: r["gold_refresh"]),
                n99=sum(r["n99"] for r in res) / n, n99_win_med=float(np.median([r["n99"] for r in wins])) if wins else float("nan"),
                vill_win=float(np.mean([r["vill"] for r in wins])) if wins else float("nan"),
                vill_win_med=float(np.median([r["vill"] for r in wins])) if wins else float("nan"),
                gold_med=float(np.median([r["earned"] for r in res])), merchant_iron=sum(r["merchant_iron"] for r in res) / n,
                merchant_rewind=sum(r.get("merchant_rewind", 0) for r in res) / n,
                rewinds_used=sum(r.get("rewinds", 0) for r in res) / n,
                relic_iron=sum(r["spent_relic_iron"] for r in res) / n, breaks=sum(r["breaks"] for r in res) / n,
                spend_iron_early_med=float(np.median([r.get("gold_merchant_iron_early", 0.0) / r["earned"] for r in res if r["earned"] > 0])) if shares else 0.0,
                spend_iron_late_med=float(np.median([r.get("gold_merchant_iron_late", 0.0) / r["earned"] for r in res if r["earned"] > 0])) if shares else 0.0,
                gold_iron_early_med=float(np.median([r.get("gold_merchant_iron_early", 0.0) for r in res])),
                gold_iron_late_med=float(np.median([r.get("gold_merchant_iron_late", 0.0) for r in res])),
                merchant_iron_early=sum(r.get("merchant_iron_early", 0) for r in res) / n,
                merchant_iron_late=sum(r.get("merchant_iron_late", 0) for r in res) / n,
                hist=hist, fine=fine)
